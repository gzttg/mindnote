/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { NoteItem, ReasonCard, NavTab, BrainEnergyFilter, NoteType, StepItem } from './types';
import { INITIAL_NOTES, INITIAL_REASONS } from './data/defaultData';
import { Sidebar } from './components/Sidebar';
import { FloatingPromptBar } from './components/FloatingPromptBar';
import { HomeDashboard } from './components/HomeDashboard';
import { NotesListView } from './components/NotesListView';
import { CalendarView } from './components/CalendarView';
import { ReasonLibraryView } from './components/ReasonLibraryView';
import { SettingsView } from './components/SettingsView';
import { QuickCaptureModal } from './components/QuickCaptureModal';
import { NoteDetailModal } from './components/NoteDetailModal';
import { SprintTimerModal } from './components/SprintTimerModal';
import { MinimalStepFocusModal } from './components/MinimalStepFocusModal';
import { playCheckStepChime, playSuccessChime } from './utils/audio';

const STORAGE_KEY_NOTES = 'mindnote_notes_v1';
const STORAGE_KEY_REASONS = 'mindnote_reasons_v1';

export default function App() {
  // Load notes from localStorage or fallback to rich initial data
  const [notes, setNotes] = useState<NoteItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_NOTES);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.warn('Failed reading notes from localStorage', e);
    }
    return INITIAL_NOTES;
  });

  // Load reasons from localStorage or fallback
  const [reasons, setReasons] = useState<ReasonCard[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_REASONS);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.warn('Failed reading reasons from localStorage', e);
    }
    return INITIAL_REASONS;
  });

  // Persist notes & reasons
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_NOTES, JSON.stringify(notes));
    } catch (e) {
      console.warn('Failed saving notes to localStorage', e);
    }
  }, [notes]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_REASONS, JSON.stringify(reasons));
    } catch (e) {
      console.warn('Failed saving reasons to localStorage', e);
    }
  }, [reasons]);

  // Navigation & Filter state
  const [currentTab, setCurrentTab] = useState<NavTab>('home');
  const [energyFilter, setEnergyFilter] = useState<BrainEnergyFilter>('all');
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);

  // Modals state
  const [isQuickCaptureOpen, setIsQuickCaptureOpen] = useState(false);
  const [quickCaptureDraft, setQuickCaptureDraft] = useState('');
  const [quickCaptureType, setQuickCaptureType] = useState<NoteType>('academic');
  const [editingNote, setEditingNote] = useState<NoteItem | null>(null);

  const [detailNote, setDetailNote] = useState<NoteItem | null>(null);
  const [sprintNote, setSprintNote] = useState<NoteItem | null>(null);
  const [minimalStepNote, setMinimalStepNote] = useState<NoteItem | null>(null);

  // Keep detailNote synchronized if notes update
  useEffect(() => {
    if (detailNote) {
      const updated = notes.find((n) => n.id === detailNote.id);
      if (updated) setDetailNote(updated);
    }
  }, [notes]);

  // Handler: Add or Edit Note
  const handleSaveNote = (noteData: Omit<NoteItem, 'id' | 'createdAt'> & { id?: string }) => {
    if (noteData.id) {
      // Edit existing
      setNotes((prev) =>
        prev.map((n) =>
          n.id === noteData.id
            ? {
                ...n,
                ...noteData,
              }
            : n
        )
      );
    } else {
      // Add new note
      const newNote: NoteItem = {
        ...noteData,
        id: `note-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        createdAt: new Date().toISOString(),
      };
      setNotes((prev) => [newNote, ...prev]);

      // If note used a reason from the library, increment usage
      if (noteData.reasonId) {
        setReasons((prev) =>
          prev.map((r) =>
            r.id === noteData.reasonId ? { ...r, timesUsed: (r.timesUsed || 0) + 1 } : r
          )
        );
      }
    }
    playCheckStepChime();
  };

  // Handler: Quick add from floating prompt bar
  const handleQuickSubmit = (title: string, type: NoteType) => {
    const newNote: NoteItem = {
      id: `note-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      type,
      title,
      content: title,
      createdAt: new Date().toISOString(),
      dueDate: new Date().toISOString().split('T')[0],
      energyLevel: type === 'memo' ? 'low' : 'high',
      tags: [type === 'academic' ? '#學術' : type === 'flow' ? '#目標' : '#生活'],
      completed: false,
      starred: false,
      minimalFirstStep: '先做2分鐘',
    };
    setNotes((prev) => [newNote, ...prev]);
    playCheckStepChime();
  };

  // Handler: Toggle complete status
  const handleToggleComplete = (id: string) => {
    setNotes((prev) =>
      prev.map((n) => {
        if (n.id === id) {
          const nextCompleted = !n.completed;
          return {
            ...n,
            completed: nextCompleted,
            // If completed, mark all sub-steps completed too
            steps: n.steps?.map((s) => ({ ...s, completed: nextCompleted })),
          };
        }
        return n;
      })
    );
  };

  // Handler: Toggle star
  const handleToggleStar = (id: string) => {
    setNotes((prev) =>
      prev.map((n) => (n.id === id ? { ...n, starred: !n.starred } : n))
    );
  };

  // Handler: Delete Note
  const handleDeleteNote = (id: string) => {
    setNotes((prev) => prev.filter((n) => n.id !== id));
  };

  // Handler: Update Steps for a note
  const handleUpdateSteps = (noteId: string, steps: StepItem[]) => {
    setNotes((prev) =>
      prev.map((n) => (n.id === noteId ? { ...n, steps } : n))
    );
  };

  // Handler: Add Reason
  const handleAddReason = (newReason: Omit<ReasonCard, 'id' | 'timesUsed'>) => {
    const card: ReasonCard = {
      ...newReason,
      id: `reason-${Date.now()}`,
      timesUsed: 0,
    };
    setReasons((prev) => [card, ...prev]);
    playCheckStepChime();
  };

  // Handler: Delete Reason
  const handleDeleteReason = (id: string) => {
    setReasons((prev) => prev.filter((r) => r.id !== id));
  };

  // Handler: Reset default demo data
  const handleResetDefault = () => {
    setNotes(INITIAL_NOTES);
    setReasons(INITIAL_REASONS);
    localStorage.setItem(STORAGE_KEY_NOTES, JSON.stringify(INITIAL_NOTES));
    localStorage.setItem(STORAGE_KEY_REASONS, JSON.stringify(INITIAL_REASONS));
  };

  // Handler: Import external backup data
  const handleImportData = (newNotes: NoteItem[], newReasons: ReasonCard[]) => {
    setNotes(newNotes);
    if (newReasons && newReasons.length > 0) {
      setReasons(newReasons);
    }
  };

  // Counts for sidebar badges
  const academicCount = notes.filter((n) => n.type === 'academic' && !n.completed).length;
  const memoCount = notes.filter((n) => n.type === 'memo' && !n.completed).length;
  const flowCount = notes.filter((n) => n.type === 'flow' && !n.completed).length;
  const reasonCount = reasons.length;

  return (
    <div className="min-h-screen bg-[#F8FAFD] flex flex-col md:flex-row text-[#1F1F1F]">
      {/* Sidebar Navigation */}
      <Sidebar
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        onOpenQuickCapture={() => {
          setEditingNote(null);
          setQuickCaptureDraft('');
          setQuickCaptureType('academic');
          setIsQuickCaptureOpen(true);
        }}
        isCollapsed={isSidebarCollapsed}
        onToggleCollapse={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
        totalNotesCount={notes.length}
        academicCount={academicCount}
        memoCount={memoCount}
        flowCount={flowCount}
        reasonCount={reasonCount}
      />

      {/* Main Work Area */}
      <main className="flex-1 min-w-0 p-4 sm:p-6 md:p-8 lg:p-10 max-w-7xl mx-auto w-full">
        {/* Gemini Floating Prompt Bar */}
        <FloatingPromptBar
          onQuickSubmit={handleQuickSubmit}
          onOpenFullModalWithDraft={(draft, type) => {
            setEditingNote(null);
            setQuickCaptureDraft(draft);
            setQuickCaptureType(type);
            setIsQuickCaptureOpen(true);
          }}
        />

        {/* Dynamic Views */}
        {currentTab === 'home' && (
          <HomeDashboard
            notes={notes}
            energyFilter={energyFilter}
            onSetEnergyFilter={setEnergyFilter}
            onToggleComplete={handleToggleComplete}
            onToggleStar={handleToggleStar}
            onDeleteNote={handleDeleteNote}
            onEditNote={(n) => {
              setEditingNote(n);
              setIsQuickCaptureOpen(true);
            }}
            onOpenDetail={setDetailNote}
            onStartSprint={setSprintNote}
            onStartMinimalStep={setMinimalStepNote}
            onSwitchTab={setCurrentTab}
          />
        )}

        {currentTab === 'academic' && (
          <NotesListView
            notes={notes}
            forcedType="academic"
            onToggleComplete={handleToggleComplete}
            onToggleStar={handleToggleStar}
            onDeleteNote={handleDeleteNote}
            onEditNote={(n) => {
              setEditingNote(n);
              setIsQuickCaptureOpen(true);
            }}
            onOpenDetail={setDetailNote}
            onStartSprint={setSprintNote}
            onStartMinimalStep={setMinimalStepNote}
            onOpenNewModal={(type) => {
              setEditingNote(null);
              setQuickCaptureDraft('');
              setQuickCaptureType(type || 'academic');
              setIsQuickCaptureOpen(true);
            }}
          />
        )}

        {currentTab === 'memo' && (
          <NotesListView
            notes={notes}
            forcedType="memo"
            onToggleComplete={handleToggleComplete}
            onToggleStar={handleToggleStar}
            onDeleteNote={handleDeleteNote}
            onEditNote={(n) => {
              setEditingNote(n);
              setIsQuickCaptureOpen(true);
            }}
            onOpenDetail={setDetailNote}
            onStartSprint={setSprintNote}
            onStartMinimalStep={setMinimalStepNote}
            onOpenNewModal={(type) => {
              setEditingNote(null);
              setQuickCaptureDraft('');
              setQuickCaptureType(type || 'memo');
              setIsQuickCaptureOpen(true);
            }}
          />
        )}

        {currentTab === 'flow' && (
          <NotesListView
            notes={notes}
            forcedType="flow"
            onToggleComplete={handleToggleComplete}
            onToggleStar={handleToggleStar}
            onDeleteNote={handleDeleteNote}
            onEditNote={(n) => {
              setEditingNote(n);
              setIsQuickCaptureOpen(true);
            }}
            onOpenDetail={setDetailNote}
            onStartSprint={setSprintNote}
            onStartMinimalStep={setMinimalStepNote}
            onOpenNewModal={(type) => {
              setEditingNote(null);
              setQuickCaptureDraft('');
              setQuickCaptureType(type || 'flow');
              setIsQuickCaptureOpen(true);
            }}
          />
        )}

        {currentTab === 'reason' && (
          <ReasonLibraryView
            reasons={reasons}
            onAddReason={handleAddReason}
            onDeleteReason={handleDeleteReason}
          />
        )}

        {currentTab === 'calendar' && (
          <CalendarView
            notes={notes}
            onOpenNoteDetail={setDetailNote}
            onStartMinimalStep={setMinimalStepNote}
          />
        )}

        {currentTab === 'search' && (
          <NotesListView
            notes={notes}
            onToggleComplete={handleToggleComplete}
            onToggleStar={handleToggleStar}
            onDeleteNote={handleDeleteNote}
            onEditNote={(n) => {
              setEditingNote(n);
              setIsQuickCaptureOpen(true);
            }}
            onOpenDetail={setDetailNote}
            onStartSprint={setSprintNote}
            onStartMinimalStep={setMinimalStepNote}
            onOpenNewModal={(type) => {
              setEditingNote(null);
              setQuickCaptureDraft('');
              setQuickCaptureType(type || 'academic');
              setIsQuickCaptureOpen(true);
            }}
          />
        )}

        {currentTab === 'settings' && (
          <SettingsView
            notes={notes}
            reasons={reasons}
            onImportData={handleImportData}
            onResetDefault={handleResetDefault}
          />
        )}
      </main>

      {/* Quick Capture / Edit Note Modal */}
      <QuickCaptureModal
        isOpen={isQuickCaptureOpen}
        initialDraft={quickCaptureDraft}
        initialType={quickCaptureType}
        editingNote={editingNote}
        reasons={reasons}
        onClose={() => {
          setIsQuickCaptureOpen(false);
          setEditingNote(null);
        }}
        onSave={handleSaveNote}
      />

      {/* Note Detailed View & Checklist Modal */}
      <NoteDetailModal
        note={detailNote}
        onClose={() => setDetailNote(null)}
        onEdit={(n) => {
          setDetailNote(null);
          setEditingNote(n);
          setIsQuickCaptureOpen(true);
        }}
        onDelete={handleDeleteNote}
        onUpdateSteps={handleUpdateSteps}
        onStartSprint={(n) => {
          setDetailNote(null);
          setSprintNote(n);
        }}
        onStartMinimalStep={(n) => {
          setDetailNote(null);
          setMinimalStepNote(n);
        }}
        onToggleComplete={handleToggleComplete}
      />

      {/* 15-Minute Micro Sprint Timer Modal */}
      <SprintTimerModal
        isOpen={Boolean(sprintNote)}
        taskTitle={sprintNote?.title || ''}
        onClose={() => setSprintNote(null)}
        onComplete={() => {
          if (sprintNote) {
            handleToggleComplete(sprintNote.id);
          }
        }}
      />

      {/* 2-Minute Minimal Step Focus Modal (ADHD breaker) */}
      <MinimalStepFocusModal
        isOpen={Boolean(minimalStepNote)}
        taskTitle={minimalStepNote?.title || ''}
        minimalStepText={minimalStepNote?.minimalFirstStep || minimalStepNote?.title || ''}
        onClose={() => setMinimalStepNote(null)}
        onComplete={() => {
          if (minimalStepNote) {
            handleToggleComplete(minimalStepNote.id);
          }
        }}
        onSwitchToSprint={() => {
          if (minimalStepNote) {
            setSprintNote(minimalStepNote);
            setMinimalStepNote(null);
          }
        }}
      />
    </div>
  );
}
