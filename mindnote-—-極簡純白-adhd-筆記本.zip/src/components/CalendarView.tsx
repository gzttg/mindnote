import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Calendar as CalendarIcon, Clock, Zap } from 'lucide-react';
import { NoteItem } from '../types';

interface CalendarViewProps {
  notes: NoteItem[];
  onOpenNoteDetail: (note: NoteItem) => void;
  onStartMinimalStep: (note: NoteItem) => void;
}

export const CalendarView: React.FC<CalendarViewProps> = ({
  notes,
  onOpenNoteDetail,
  onStartMinimalStep,
}) => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDateStr, setSelectedDateStr] = useState<string>(
    new Date().toISOString().split('T')[0]
  );

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  // Month navigation
  const prevMonth = () => {
    setCurrentDate(new Date(year, month - 1, 1));
  };
  const nextMonth = () => {
    setCurrentDate(new Date(year, month + 1, 1));
  };
  const jumpToToday = () => {
    const today = new Date();
    setCurrentDate(today);
    setSelectedDateStr(today.toISOString().split('T')[0]);
  };

  // Calendar math
  const firstDayIndex = new Date(year, month, 1).getDay(); // 0 is Sunday
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const daysInPrevMonth = new Date(year, month, 0).getDate();

  const calendarDays = [];

  // Previous month trailing days
  for (let i = firstDayIndex - 1; i >= 0; i--) {
    const d = daysInPrevMonth - i;
    const dateObj = new Date(year, month - 1, d);
    const dateStr = dateObj.toISOString().split('T')[0];
    calendarDays.push({ dayNumber: d, isCurrentMonth: false, dateStr });
  }

  // Current month days
  for (let d = 1; d <= daysInMonth; d++) {
    const dateObj = new Date(year, month, d);
    const dateStr = dateObj.toISOString().split('T')[0];
    calendarDays.push({ dayNumber: d, isCurrentMonth: true, dateStr });
  }

  // Next month leading days to complete grid
  const remaining = (7 - (calendarDays.length % 7)) % 7;
  for (let d = 1; d <= remaining; d++) {
    const dateObj = new Date(year, month + 1, d);
    const dateStr = dateObj.toISOString().split('T')[0];
    calendarDays.push({ dayNumber: d, isCurrentMonth: false, dateStr });
  }

  // Map notes by dueDate
  const notesByDate: Record<string, NoteItem[]> = {};
  notes.forEach((n) => {
    if (n.dueDate) {
      const dateKey = n.dueDate.split('T')[0];
      if (!notesByDate[dateKey]) notesByDate[dateKey] = [];
      notesByDate[dateKey].push(n);
    }
  });

  const selectedDateNotes = notesByDate[selectedDateStr] || [];
  const todayStr = new Date().toISOString().split('T')[0];

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="p-1.5 rounded-full bg-blue-100 text-blue-700">
              <CalendarIcon className="w-5 h-5" />
            </span>
            <h1 className="text-2xl font-bold text-[#1F1F1F]">📅 日曆視圖（時間盲區救星）</h1>
          </div>
          <p className="text-xs text-[#5F6368]">
            「一眼看清任務密度與截止日。」點擊日期查看專屬任務，視覺化防拖延。
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={jumpToToday}
            className="pill-btn px-4 py-2 bg-white border border-[#DCE3E9] text-xs font-semibold text-[#1F1F1F] hover:bg-[#F0F4F9]"
          >
            返回今天
          </button>
          <div className="flex items-center bg-white border border-[#DCE3E9] rounded-full p-1">
            <button
              onClick={prevMonth}
              className="p-1.5 rounded-full hover:bg-gray-100 text-gray-600 transition-colors"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="text-xs font-bold text-[#1F1F1F] px-3 font-mono">
              {year} 年 {month + 1} 月
            </span>
            <button
              onClick={nextMonth}
              className="p-1.5 rounded-full hover:bg-gray-100 text-gray-600 transition-colors"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Calendar Grid Container */}
      <div className="bg-white border border-[#E9EEF6] rounded-3xl p-6 shadow-[0_4px_20px_rgba(15,23,42,0.03)]">
        {/* Days of week */}
        <div className="grid grid-cols-7 gap-1 text-center font-semibold text-xs text-[#5F6368] mb-3">
          <span>日</span>
          <span>一</span>
          <span>二</span>
          <span>三</span>
          <span>四</span>
          <span>五</span>
          <span>六</span>
        </div>

        {/* Days grid */}
        <div className="grid grid-cols-7 gap-1.5 sm:gap-2">
          {calendarDays.map((cDay, idx) => {
            const hasNotes = notesByDate[cDay.dateStr];
            const isSelected = selectedDateStr === cDay.dateStr;
            const isToday = todayStr === cDay.dateStr;

            return (
              <div
                key={idx}
                onClick={() => setSelectedDateStr(cDay.dateStr)}
                className={`min-h-[70px] sm:min-h-[85px] p-2 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between ${
                  isSelected
                    ? 'border-[#0B57D0] ring-2 ring-blue-100 bg-blue-50/20'
                    : isToday
                    ? 'border-blue-300 bg-white'
                    : cDay.isCurrentMonth
                    ? 'border-[#E9EEF6] bg-white hover:border-gray-300'
                    : 'border-transparent bg-gray-50/50 opacity-40 hover:opacity-70'
                }`}
              >
                <div className="flex justify-between items-center">
                  <span
                    className={`text-xs font-semibold rounded-full w-6 h-6 flex items-center justify-center ${
                      isToday
                        ? 'bg-[#0B57D0] text-white font-bold'
                        : isSelected
                        ? 'text-[#0B57D0] font-bold'
                        : 'text-[#1F1F1F]'
                    }`}
                  >
                    {cDay.dayNumber}
                  </span>
                  {hasNotes && (
                    <span className="text-[10px] text-gray-400 font-mono">
                      {hasNotes.length}
                    </span>
                  )}
                </div>

                {/* Event indicators (colored dots) */}
                <div className="flex items-center gap-1 flex-wrap pt-1">
                  {hasNotes?.slice(0, 4).map((n) => {
                    let dotColor = 'bg-blue-500';
                    if (n.type === 'academic') dotColor = 'bg-red-500';
                    if (n.type === 'flow') dotColor = 'bg-emerald-500';
                    if (n.type === 'reason') dotColor = 'bg-purple-500';
                    return (
                      <span
                        key={n.id}
                        title={n.title}
                        className={`w-2 h-2 rounded-full ${dotColor} shrink-0`}
                      />
                    );
                  })}
                  {hasNotes && hasNotes.length > 4 && (
                    <span className="text-[9px] text-gray-400">+{hasNotes.length - 4}</span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Selected Day Agenda */}
      <div className="bg-white border border-[#E9EEF6] rounded-3xl p-6 shadow-[0_4px_20px_rgba(15,23,42,0.03)]">
        <div className="flex items-center justify-between mb-4 pb-3 border-b border-gray-100">
          <div>
            <h3 className="font-bold text-base text-[#1F1F1F]">
              📅 {selectedDateStr} 的待辦事項
            </h3>
            <p className="text-xs text-[#5F6368]">
              共 {selectedDateNotes.length} 項任務排定於此日
            </p>
          </div>
          {selectedDateStr === todayStr && (
            <span className="px-3 py-1 rounded-full text-xs font-bold bg-blue-50 text-[#0B57D0]">
              今天
            </span>
          )}
        </div>

        {selectedDateNotes.length === 0 ? (
          <div className="py-8 text-center text-xs text-[#5F6368]">
            <p>這一天目前沒有排定的學術作業或計劃流。</p>
            <p className="text-gray-400 mt-1">好好放鬆充電，或是點擊上方「快速寫入」添加新任務！</p>
          </div>
        ) : (
          <div className="space-y-3">
            {selectedDateNotes.map((n) => (
              <div
                key={n.id}
                className="flex items-center justify-between p-3.5 rounded-2xl bg-[#F8FAFD] border border-[#E9EEF6] hover:bg-white transition-all gap-3"
              >
                <div
                  onClick={() => onOpenNoteDetail(n)}
                  className="flex-1 cursor-pointer overflow-hidden"
                >
                  <div className="flex items-center gap-2 mb-1">
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        n.type === 'academic'
                          ? 'bg-[#FEF2F2] text-[#B91C1C]'
                          : n.type === 'flow'
                          ? 'bg-[#F0FDF4] text-[#15803D]'
                          : 'bg-[#EFF6FF] text-[#1D4ED8]'
                      }`}
                    >
                      {n.type === 'academic' ? '學術' : n.type === 'flow' ? '計劃流' : '備忘'}
                    </span>
                    <span
                      className={`text-sm font-semibold truncate ${
                        n.completed ? 'line-through text-gray-400' : 'text-[#1F1F1F]'
                      }`}
                    >
                      {n.title}
                    </span>
                  </div>

                  {n.minimalFirstStep && (
                    <div className="flex items-center gap-1 text-xs text-amber-800">
                      <Zap className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                      <span>{n.minimalFirstStep}</span>
                    </div>
                  )}
                </div>

                {n.minimalFirstStep && !n.completed && (
                  <button
                    onClick={() => onStartMinimalStep(n)}
                    className="pill-btn shrink-0 px-3 py-1.5 text-xs font-bold bg-amber-500 hover:bg-amber-600 text-white"
                  >
                    ⚡ 先做2分鐘
                  </button>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
