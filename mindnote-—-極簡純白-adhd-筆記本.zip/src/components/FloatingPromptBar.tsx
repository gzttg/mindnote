import React, { useState, useEffect } from 'react';
import { Mic, MicOff, Send, SlidersHorizontal, Sparkles } from 'lucide-react';
import { NoteType } from '../types';
import { createSpeechHelper } from '../utils/speech';
import { playCheckStepChime } from '../utils/audio';

interface FloatingPromptBarProps {
  onQuickSubmit: (title: string, type: NoteType) => void;
  onOpenFullModalWithDraft: (draft: string, type: NoteType) => void;
}

export const FloatingPromptBar: React.FC<FloatingPromptBarProps> = ({
  onQuickSubmit,
  onOpenFullModalWithDraft,
}) => {
  const [inputVal, setInputVal] = useState('');
  const [selectedType, setSelectedType] = useState<NoteType>('academic');
  const [isListening, setIsListening] = useState(false);
  const [speechError, setSpeechError] = useState<string | null>(null);

  const speechHelper = React.useMemo(() => createSpeechHelper(), []);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (speechError) {
      timer = setTimeout(() => setSpeechError(null), 4000);
    }
    return () => clearTimeout(timer);
  }, [speechError]);

  const handleToggleVoice = () => {
    if (!speechHelper.isSupported) {
      setSpeechError('瀏覽器暫不支援語音辨識');
      return;
    }

    if (isListening) {
      setIsListening(false);
    } else {
      setIsListening(true);
      const stopFn = speechHelper.start(
        (transcript) => {
          setInputVal((prev) => (prev ? `${prev} ${transcript}` : transcript));
        },
        (err) => {
          setSpeechError(err);
          setIsListening(false);
        },
        () => {
          setIsListening(false);
        }
      );
      // Auto stop cleanup if needed
      return stopFn;
    }
  };

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputVal.trim()) return;
    onQuickSubmit(inputVal.trim(), selectedType);
    setInputVal('');
    playCheckStepChime();
  };

  const handleOpenDetailed = () => {
    onOpenFullModalWithDraft(inputVal.trim(), selectedType);
  };

  return (
    <div className="w-full mb-8">
      <div className="gemini-input-glow bg-white border border-[#E9EEF6] rounded-[28px] p-2.5 px-5 shadow-[0_4px_20px_rgba(15,23,42,0.03)] transition-all">
        {/* Input Form */}
        <form onSubmit={handleSubmit} className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-blue-50 flex items-center justify-center text-blue-600 shrink-0">
            <Sparkles className="w-4 h-4" />
          </div>

          <input
            type="text"
            value={inputVal}
            onChange={(e) => setInputVal(e.target.value)}
            placeholder="有什麼想法或待辦？輸入並按 Enter 立即閃電寫入..."
            className="flex-1 bg-transparent border-none outline-none text-[#1F1F1F] text-sm md:text-base placeholder:text-[#9AA0A6]"
          />

          {/* Voice Input Button */}
          {speechHelper.isSupported && (
            <button
              type="button"
              onClick={handleToggleVoice}
              title={isListening ? '停止語音輸入' : '點擊開始語音閃電輸入'}
              className={`p-2 rounded-full transition-all ${
                isListening
                  ? 'bg-red-500 text-white animate-pulse shadow-md'
                  : 'hover:bg-[#F0F4F9] text-[#5F6368]'
              }`}
            >
              {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
            </button>
          )}

          {/* Quick Submit */}
          <button
            type="submit"
            disabled={!inputVal.trim()}
            className={`p-2 rounded-full transition-all ${
              inputVal.trim()
                ? 'bg-[#0B57D0] hover:bg-[#0842A0] text-white shadow-xs'
                : 'text-gray-300 cursor-not-allowed'
            }`}
          >
            <Send className="w-4 h-4" />
          </button>
        </form>

        {/* Quick Type Pills & Expand Action Bar */}
        <div className="flex items-center justify-between pt-2.5 mt-1.5 border-t border-[#F0F4F9] flex-wrap gap-2 text-xs">
          <div className="flex items-center gap-1.5">
            <span className="text-[11px] text-[#5F6368] mr-1 hidden sm:inline">分類:</span>
            <button
              type="button"
              onClick={() => setSelectedType('academic')}
              className={`px-3 py-1 rounded-full text-xs font-medium transition-all ${
                selectedType === 'academic'
                  ? 'bg-[#FEF2F2] border border-[#FECACA] text-[#B91C1C] font-semibold'
                  : 'bg-white border border-[#DCE3E9] text-[#5F6368] hover:bg-[#F0F4F9]'
              }`}
            >
              🔴 學術課業
            </button>
            <button
              type="button"
              onClick={() => setSelectedType('memo')}
              className={`px-3 py-1 rounded-full text-xs font-medium transition-all ${
                selectedType === 'memo'
                  ? 'bg-[#EFF6FF] border border-[#BFDBFE] text-[#1D4ED8] font-semibold'
                  : 'bg-white border border-[#DCE3E9] text-[#5F6368] hover:bg-[#F0F4F9]'
              }`}
            >
              🔵 備忘錄
            </button>
            <button
              type="button"
              onClick={() => setSelectedType('flow')}
              className={`px-3 py-1 rounded-full text-xs font-medium transition-all ${
                selectedType === 'flow'
                  ? 'bg-[#F0FDF4] border border-[#BBF7D0] text-[#15803D] font-semibold'
                  : 'bg-white border border-[#DCE3E9] text-[#5F6368] hover:bg-[#F0F4F9]'
              }`}
            >
              🟢 計劃流
            </button>
            <button
              type="button"
              onClick={() => setSelectedType('reason')}
              className={`px-3 py-1 rounded-full text-xs font-medium transition-all ${
                selectedType === 'reason'
                  ? 'bg-[#FAF5FF] border border-[#E9D5FF] text-[#7E22CE] font-semibold'
                  : 'bg-white border border-[#DCE3E9] text-[#5F6368] hover:bg-[#F0F4F9]'
              }`}
            >
              🟣 原因動機
            </button>
          </div>

          <button
            type="button"
            onClick={handleOpenDetailed}
            className="flex items-center gap-1.5 text-xs text-[#0B57D0] hover:text-[#0842A0] font-medium px-2 py-1 rounded-full hover:bg-blue-50/60 transition-colors"
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>展開步驟與原因詳細表單</span>
          </button>
        </div>
      </div>

      {/* Speech feedback banner */}
      {isListening && (
        <div className="mt-2 text-xs text-red-600 bg-red-50 border border-red-200 px-3.5 py-1.5 rounded-full inline-flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
          <span>正在聆聽中... 請說話（例如：「週五前繳交分子生物學報告」）</span>
        </div>
      )}

      {speechError && (
        <div className="mt-2 text-xs text-amber-700 bg-amber-50 border border-amber-200 px-3.5 py-1.5 rounded-full">
          {speechError}
        </div>
      )}
    </div>
  );
};
