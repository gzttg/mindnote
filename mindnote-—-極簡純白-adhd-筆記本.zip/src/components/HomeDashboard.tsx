import React from 'react';
import {
  Calendar,
  Zap,
  Flame,
  CheckCircle2,
  Circle,
  BatteryCharging,
  BatteryLow,
  Sparkles,
  ArrowRight,
  TrendingUp,
} from 'lucide-react';
import { NoteItem, BrainEnergyFilter, NoteType } from '../types';
import { NoteCard } from './NoteCard';
import { playCheckStepChime, playSuccessChime } from '../utils/audio';

interface HomeDashboardProps {
  notes: NoteItem[];
  energyFilter: BrainEnergyFilter;
  onSetEnergyFilter: (f: BrainEnergyFilter) => void;
  onToggleComplete: (id: string) => void;
  onToggleStar: (id: string) => void;
  onDeleteNote: (id: string) => void;
  onEditNote: (note: NoteItem) => void;
  onOpenDetail: (note: NoteItem) => void;
  onStartSprint: (note: NoteItem) => void;
  onStartMinimalStep: (note: NoteItem) => void;
  onSwitchTab: (tab: any) => void;
}

export const HomeDashboard: React.FC<HomeDashboardProps> = ({
  notes,
  energyFilter,
  onSetEnergyFilter,
  onToggleComplete,
  onToggleStar,
  onDeleteNote,
  onEditNote,
  onOpenDetail,
  onStartSprint,
  onStartMinimalStep,
  onSwitchTab,
}) => {
  // Today's formatted date
  const todayFormatted = new Intl.DateTimeFormat('zh-TW', {
    month: 'long',
    day: 'numeric',
    weekday: 'long',
  }).format(new Date());

  // Filter notes by energy level
  const energyFilteredNotes = notes.filter((n) => {
    if (energyFilter === 'all') return true;
    return n.energyLevel === energyFilter;
  });

  // Pending actions (incomplete, sorted with priority)
  const pendingTodos = energyFilteredNotes.filter((n) => !n.completed);
  const completedTodos = energyFilteredNotes.filter((n) => n.completed);

  // Recent notes (latest 6)
  const recentNotes = energyFilteredNotes.slice(0, 6);

  // Time remaining helper for checklist
  const getDueDaysText = (dueDate?: string) => {
    if (!dueDate) return null;
    const now = new Date();
    now.setHours(0, 0, 0, 0);
    const due = new Date(dueDate);
    due.setHours(0, 0, 0, 0);

    const diffDays = Math.ceil((due.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    if (diffDays < 0) return { text: `逾期 ${Math.abs(diffDays)} 天`, color: 'text-red-600 bg-red-50' };
    if (diffDays === 0) return { text: '⚠️ 今天截止', color: 'text-amber-700 bg-amber-50 font-bold' };
    if (diffDays === 1) return { text: '⏳ 明天截止', color: 'text-orange-700 bg-orange-50' };
    return { text: `⏳ 剩餘 ${diffDays} 天`, color: 'text-slate-600 bg-slate-50' };
  };

  return (
    <div className="space-y-8">
      {/* Date & Spiritual Slogan Banner */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-2 border-b border-[#F0F4F9]">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-[#0B57D0] mb-1">
            <Calendar className="w-3.5 h-3.5" />
            <span>{todayFormatted}</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#1F1F1F] tracking-tight">
            今日行動中心
          </h1>
          <p className="text-xs sm:text-sm text-[#5F6368] mt-1">
            「不是只記下來，而是讓你願意做下去。」· 小小的行動，會帶來巨大的改變。
          </p>
        </div>

        {/* 🔋 Brain Energy Filter Pills */}
        <div className="flex items-center gap-1.5 p-1 bg-white border border-[#E9EEF6] rounded-full shadow-2xs self-start md:self-auto">
          <span className="text-[11px] font-semibold text-[#5F6368] px-2.5 hidden sm:inline">
            大腦電量:
          </span>
          <button
            onClick={() => onSetEnergyFilter('all')}
            className={`pill-btn px-3 py-1.5 text-xs font-semibold rounded-full transition-all ${
              energyFilter === 'all'
                ? 'bg-[#1F1F1F] text-white shadow-xs'
                : 'text-[#5F6368] hover:text-[#1F1F1F]'
            }`}
          >
            全部
          </button>
          <button
            onClick={() => onSetEnergyFilter('high')}
            className={`pill-btn px-3 py-1.5 text-xs font-semibold rounded-full flex items-center gap-1 transition-all ${
              energyFilter === 'high'
                ? 'bg-amber-100 text-amber-900 border border-amber-300 font-bold shadow-xs'
                : 'text-[#5F6368] hover:text-[#1F1F1F]'
            }`}
          >
            <BatteryCharging className="w-3.5 h-3.5 text-amber-600" />
            <span>🔋 高能量燒腦</span>
          </button>
          <button
            onClick={() => onSetEnergyFilter('low')}
            className={`pill-btn px-3 py-1.5 text-xs font-semibold rounded-full flex items-center gap-1 transition-all ${
              energyFilter === 'low'
                ? 'bg-sky-100 text-sky-900 border border-sky-300 font-bold shadow-xs'
                : 'text-[#5F6368] hover:text-[#1F1F1F]'
            }`}
          >
            <BatteryLow className="w-3.5 h-3.5 text-sky-600" />
            <span>🪫 低能量無腦</span>
          </button>
        </div>
      </div>

      {/* Today's Action Checklist Block (Anti-Inertia) */}
      <div className="bg-white border border-[#E9EEF6] rounded-3xl p-6 sm:p-7 shadow-[0_4px_20px_rgba(15,23,42,0.03)]">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <span className="p-1 rounded-full bg-amber-100 text-amber-800">
              <Zap className="w-4 h-4 fill-amber-500 text-amber-500" />
            </span>
            <h2 className="text-base sm:text-lg font-bold text-[#1F1F1F]">
              待辦清單與救援按鈕
            </h2>
          </div>
          <span className="text-xs text-[#5F6368] font-medium font-mono">
            進行中 {pendingTodos.length} 項 · 已完成 {completedTodos.length} 項
          </span>
        </div>

        {pendingTodos.length === 0 ? (
          <div className="py-8 text-center text-xs text-[#5F6368] space-y-2">
            <p className="font-semibold text-emerald-600">🎉 目前沒有待辦事項！</p>
            <p className="text-gray-400">大腦能量充足，可上方輸入快速記下新靈感。</p>
          </div>
        ) : (
          <div className="space-y-2.5">
            {pendingTodos.map((note) => {
              const dueInfo = getDueDaysText(note.dueDate);
              return (
                <div
                  key={note.id}
                  className="flex flex-col sm:flex-row sm:items-center justify-between p-3.5 rounded-2xl bg-[#F8FAFD] border border-[#E9EEF6] hover:bg-white hover:border-[#DCE3E9] transition-all gap-3"
                >
                  <div className="flex items-start gap-3 flex-1 overflow-hidden">
                    <button
                      onClick={() => {
                        onToggleComplete(note.id);
                        playSuccessChime();
                      }}
                      className="mt-0.5 text-gray-300 hover:text-emerald-500 transition-colors shrink-0"
                    >
                      <Circle className="w-5 h-5" />
                    </button>

                    <div className="overflow-hidden flex-1">
                      <div className="flex items-center gap-2 flex-wrap mb-1">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            note.type === 'academic'
                              ? 'bg-[#FEF2F2] text-[#B91C1C]'
                              : note.type === 'flow'
                              ? 'bg-[#F0FDF4] text-[#15803D]'
                              : note.type === 'reason'
                              ? 'bg-[#FAF5FF] text-[#7E22CE]'
                              : 'bg-[#EFF6FF] text-[#1D4ED8]'
                          }`}
                        >
                          {note.type === 'academic'
                            ? '🔴 學術'
                            : note.type === 'flow'
                            ? '🟢 計劃'
                            : note.type === 'reason'
                            ? '🟣 原因'
                            : '🔵 備忘'}
                        </span>

                        <h3
                          onClick={() => onOpenDetail(note)}
                          className="font-bold text-sm text-[#1F1F1F] truncate cursor-pointer hover:text-[#0B57D0]"
                        >
                          {note.title}
                        </h3>

                        {dueInfo && (
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-medium border border-transparent ${dueInfo.color}`}
                          >
                            {dueInfo.text}
                          </span>
                        )}
                      </div>

                      {/* Minimal First Step Callout */}
                      {note.minimalFirstStep && (
                        <p className="text-xs text-amber-900/90 flex items-center gap-1 truncate font-medium">
                          <Zap className="w-3.5 h-3.5 text-amber-500 fill-amber-500 shrink-0" />
                          <span>第一步：{note.minimalFirstStep}</span>
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Rescue & Sprint Micro Buttons */}
                  <div className="flex items-center gap-2 self-end sm:self-auto shrink-0">
                    {note.minimalFirstStep && (
                      <button
                        onClick={() => onStartMinimalStep(note)}
                        className="pill-btn px-3 py-1.5 text-xs font-bold bg-amber-500 hover:bg-amber-600 text-white shadow-2xs flex items-center gap-1"
                      >
                        <Zap className="w-3.5 h-3.5 fill-white" />
                        <span>先做2分鐘</span>
                      </button>
                    )}

                    <button
                      onClick={() => onStartSprint(note)}
                      className="pill-btn px-3 py-1.5 text-xs font-medium bg-white border border-[#DCE3E9] text-[#0B57D0] hover:bg-[#F0F4F9] flex items-center gap-1"
                    >
                      <Flame className="w-3.5 h-3.5" />
                      <span>微衝刺</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Recent Notes Stream */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-base sm:text-lg font-bold text-[#1F1F1F]">
            最近筆記與行動卡片
          </h2>
          <button
            onClick={() => onSwitchTab('search')}
            className="flex items-center gap-1 text-xs text-[#0B57D0] hover:text-[#0842A0] font-semibold"
          >
            <span>瀏覽全部</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {recentNotes.map((note) => (
            <NoteCard
              key={note.id}
              note={note}
              onToggleComplete={onToggleComplete}
              onToggleStar={onToggleStar}
              onDelete={onDeleteNote}
              onEdit={onEditNote}
              onOpenDetail={onOpenDetail}
              onStartSprint={onStartSprint}
              onStartMinimalStep={onStartMinimalStep}
            />
          ))}
        </div>
      </div>
    </div>
  );
};
