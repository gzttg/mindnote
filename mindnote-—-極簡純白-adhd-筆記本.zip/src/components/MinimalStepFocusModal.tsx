import React, { useState, useEffect } from 'react';
import { X, Zap, CheckCircle2, Play, Pause, Flame } from 'lucide-react';
import { playSuccessChime, playStartSprintChime } from '../utils/audio';

interface MinimalStepFocusModalProps {
  isOpen: boolean;
  taskTitle: string;
  minimalStepText: string;
  onClose: () => void;
  onComplete: () => void;
  onSwitchToSprint: () => void;
}

const TWO_MINUTES_SEC = 2 * 60; // 120 seconds

export const MinimalStepFocusModal: React.FC<MinimalStepFocusModalProps> = ({
  isOpen,
  taskTitle,
  minimalStepText,
  onClose,
  onComplete,
  onSwitchToSprint,
}) => {
  const [secondsLeft, setSecondsLeft] = useState(TWO_MINUTES_SEC);
  const [isActive, setIsActive] = useState(false);
  const [isDone, setIsDone] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setSecondsLeft(TWO_MINUTES_SEC);
      setIsActive(true);
      setIsDone(false);
      playStartSprintChime();
    }
  }, [isOpen]);

  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (isActive && secondsLeft > 0) {
      interval = setInterval(() => {
        setSecondsLeft((s) => s - 1);
      }, 1000);
    } else if (secondsLeft === 0 && isActive) {
      setIsActive(false);
      setIsDone(true);
      playSuccessChime();
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isActive, secondsLeft]);

  if (!isOpen) return null;

  const minutes = Math.floor(secondsLeft / 60);
  const seconds = secondsLeft % 60;
  const progressPercent = ((TWO_MINUTES_SEC - secondsLeft) / TWO_MINUTES_SEC) * 100;

  const handleFinish = () => {
    setIsDone(true);
    playSuccessChime();
    setTimeout(() => {
      onComplete();
      onClose();
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-slate-900/60 backdrop-blur-md">
      <div className="bg-white rounded-3xl w-full max-w-xl p-8 sm:p-12 shadow-[0_25px_60px_rgba(15,23,42,0.2)] border border-[#E9EEF6] text-center animate-in zoom-in-95 duration-200 relative">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-6 right-6 p-2 rounded-full hover:bg-gray-100 text-[#5F6368] transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Badge */}
        <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-amber-50 border border-amber-200 text-amber-800 text-xs font-bold mb-6">
          <Zap className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
          <span>ADHD 減壓 · 聚焦最小第一步</span>
        </div>

        {/* Task Subtitle */}
        <p className="text-xs text-[#5F6368] mb-2 font-medium">母任務：{taskTitle}</p>

        {/* Minimal Step Giant Focus Box */}
        <div className="bg-[#FFFBEB] border-2 border-[#FDE68A] rounded-2xl p-6 sm:p-8 mb-8 shadow-xs">
          <p className="text-[11px] uppercase tracking-wider font-semibold text-amber-800/80 mb-2">
            現在此時此刻，你只需要做這件事：
          </p>
          <h2 className="text-xl sm:text-2xl font-extrabold text-[#1F1F1F] leading-snug">
            {minimalStepText || '先做最簡單的動作 2 分鐘'}
          </h2>
        </div>

        {/* 2-Minute Progress Bar & Timer */}
        <div className="mb-8">
          <div className="flex items-center justify-between text-xs font-semibold text-[#5F6368] mb-2 px-1">
            <span>2 分鐘破冰倒數</span>
            <span className="font-mono text-sm font-bold text-[#1F1F1F]">
              {String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
            </span>
          </div>

          <div className="w-full bg-gray-100 h-3 rounded-full overflow-hidden">
            <div
              className="bg-amber-500 h-full rounded-full transition-all duration-1000 ease-linear"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>

        {/* Encouraging Quote */}
        <p className="text-xs text-[#5F6368] leading-relaxed mb-8 max-w-md mx-auto">
          「不要去想把整份做完，只要坐在椅子上把這一步做完，大腦的抗拒感就會瞬間瓦解。」
        </p>

        {/* Action Controls */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
          <button
            onClick={() => setIsActive(!isActive)}
            className="pill-btn px-4 py-2.5 rounded-full border border-[#DCE3E9] text-xs font-semibold text-[#5F6368] hover:bg-gray-50 flex items-center gap-1.5"
          >
            {isActive ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
            <span>{isActive ? '暫停計時' : '繼續計時'}</span>
          </button>

          <button
            onClick={handleFinish}
            className="pill-btn w-full sm:w-auto px-8 py-3 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm shadow-md flex items-center justify-center gap-2"
          >
            <CheckCircle2 className="w-5 h-5" />
            <span>我做完第一步了！</span>
          </button>

          <button
            onClick={() => {
              onClose();
              onSwitchToSprint();
            }}
            className="pill-btn px-4 py-2.5 rounded-full bg-blue-50 hover:bg-blue-100 text-[#0B57D0] text-xs font-semibold flex items-center gap-1.5"
          >
            <Flame className="w-3.5 h-3.5" />
            <span>手感來了，進入 15 分鐘衝刺</span>
          </button>
        </div>
      </div>
    </div>
  );
};
