import React from 'react';
import {
  Star,
  CheckCircle2,
  Circle,
  Clock,
  Zap,
  Flame,
  MoreHorizontal,
  Trash2,
  Edit3,
} from 'lucide-react';
import { NoteItem } from '../types';
import { playCheckStepChime } from '../utils/audio';

interface NoteCardProps {
  note: NoteItem;
  onToggleComplete: (id: string) => void;
  onToggleStar: (id: string) => void;
  onDelete: (id: string) => void;
  onEdit: (note: NoteItem) => void;
  onOpenDetail: (note: NoteItem) => void;
  onStartSprint: (note: NoteItem) => void;
  onStartMinimalStep: (note: NoteItem) => void;
}

export const NoteCard: React.FC<NoteCardProps> = ({
  note,
  onToggleComplete,
  onToggleStar,
  onDelete,
  onEdit,
  onOpenDetail,
  onStartSprint,
  onStartMinimalStep,
}) => {
  const [showMenu, setShowMenu] = React.useState(false);

  // Calculate remaining days for anti-time blindness
  const getDueStatus = () => {
    if (!note.dueDate) return null;
    const now = new Date();
    now.setHours(0, 0, 0, 0);
    const due = new Date(note.dueDate);
    due.setHours(0, 0, 0, 0);

    const diffTime = due.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays < 0) {
      return { text: `逾期 ${Math.abs(diffDays)} 天`, color: 'text-red-600 bg-red-50 border-red-200' };
    } else if (diffDays === 0) {
      return { text: '⚠️ 今天截止', color: 'text-amber-700 bg-amber-50 border-amber-200 font-bold' };
    } else if (diffDays === 1) {
      return { text: '⏳ 明天截止', color: 'text-orange-700 bg-orange-50 border-orange-200' };
    } else {
      return { text: `⏳ 剩餘 ${diffDays} 天`, color: 'text-slate-600 bg-slate-50 border-slate-200' };
    }
  };

  const dueStatus = getDueStatus();

  // Category Pastel Styles
  const getCategoryBadge = () => {
    switch (note.type) {
      case 'academic':
        return (
          <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-[#FEF2F2] border border-[#FECACA] text-[#B91C1C]">
            🔴 學術課業
          </span>
        );
      case 'memo':
        return (
          <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-[#EFF6FF] border border-[#BFDBFE] text-[#1D4ED8]">
            🔵 備忘錄
          </span>
        );
      case 'flow':
        return (
          <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-[#F0FDF4] border border-[#BBF7D0] text-[#15803D]">
            🟢 計劃流
          </span>
        );
      case 'reason':
        return (
          <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-[#FAF5FF] border border-[#E9D5FF] text-[#7E22CE]">
            🟣 原因動機
          </span>
        );
    }
  };

  // Steps calculation
  const totalSteps = note.steps?.length || 0;
  const completedSteps = note.steps?.filter((s) => s.completed).length || 0;
  const progressPercent = totalSteps > 0 ? (completedSteps / totalSteps) * 100 : 0;

  return (
    <div
      className={`card-hover-subtle bg-white border border-[#E9EEF6] rounded-3xl p-6 shadow-[0_4px_20px_rgba(15,23,42,0.03)] flex flex-col justify-between transition-all relative ${
        note.completed ? 'opacity-70 bg-slate-50/50' : ''
      }`}
    >
      <div>
        {/* Header Bar */}
        <div className="flex items-center justify-between gap-2 mb-3">
          <div className="flex items-center gap-1.5 flex-wrap">
            {getCategoryBadge()}
            {note.energyLevel && (
              <span
                className={`px-2 py-0.5 rounded-full text-[11px] font-medium border ${
                  note.energyLevel === 'high'
                    ? 'bg-amber-50 border-amber-200 text-amber-800'
                    : 'bg-sky-50 border-sky-200 text-sky-800'
                }`}
              >
                {note.energyLevel === 'high' ? '🔋 高能' : '🪫 低能'}
              </span>
            )}
            {dueStatus && (
              <span
                className={`px-2 py-0.5 rounded-full text-[11px] border font-medium ${dueStatus.color}`}
              >
                {dueStatus.text}
              </span>
            )}
          </div>

          {/* Star & Actions Menu */}
          <div className="flex items-center gap-1">
            <button
              onClick={() => onToggleStar(note.id)}
              className="p-1.5 rounded-full hover:bg-gray-100 text-gray-400 hover:text-amber-400 transition-colors"
              title={note.starred ? '取消收藏' : '標記星號'}
            >
              <Star
                className={`w-4 h-4 ${note.starred ? 'text-amber-400 fill-amber-400' : ''}`}
              />
            </button>

            <div className="relative">
              <button
                onClick={() => setShowMenu(!showMenu)}
                className="p-1.5 rounded-full hover:bg-gray-100 text-[#5F6368] transition-colors"
              >
                <MoreHorizontal className="w-4 h-4" />
              </button>

              {showMenu && (
                <div
                  onMouseLeave={() => setShowMenu(false)}
                  className="absolute right-0 top-full mt-1 w-32 bg-white rounded-2xl shadow-lg border border-[#E9EEF6] p-1.5 z-20 space-y-1 text-xs"
                >
                  <button
                    onClick={() => {
                      setShowMenu(false);
                      onEdit(note);
                    }}
                    className="w-full flex items-center gap-2 px-3 py-1.5 rounded-xl hover:bg-gray-50 text-gray-700"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                    <span>編輯筆記</span>
                  </button>
                  <button
                    onClick={() => {
                      setShowMenu(false);
                      onDelete(note.id);
                    }}
                    className="w-full flex items-center gap-2 px-3 py-1.5 rounded-xl hover:bg-red-50 text-red-600"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>刪除</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Title & Checkbox */}
        <div className="flex items-start gap-3 mb-2.5">
          <button
            onClick={() => {
              onToggleComplete(note.id);
              playCheckStepChime();
            }}
            className="mt-1 text-gray-400 hover:text-emerald-600 transition-colors shrink-0"
          >
            {note.completed ? (
              <CheckCircle2 className="w-5 h-5 text-emerald-600 fill-emerald-50" />
            ) : (
              <Circle className="w-5 h-5 text-gray-300 hover:text-emerald-500" />
            )}
          </button>

          <h3
            onClick={() => onOpenDetail(note)}
            className={`font-bold text-base text-[#1F1F1F] leading-snug cursor-pointer hover:text-[#0B57D0] transition-colors ${
              note.completed ? 'line-through text-gray-400' : ''
            }`}
          >
            {note.title}
          </h3>
        </div>

        {/* Content Snippet */}
        {note.content && (
          <p
            onClick={() => onOpenDetail(note)}
            className="text-xs text-[#5F6368] line-clamp-3 mb-3.5 leading-relaxed cursor-pointer"
          >
            {note.content}
          </p>
        )}

        {/* Reason Box (Why) */}
        {note.reason && (
          <div className="mb-3.5 p-3 rounded-2xl bg-[#FAF5FF] border border-[#E9D5FF] text-xs">
            <div className="flex items-center gap-1 text-[11px] font-bold text-[#7E22CE] mb-1">
              <span>💡 為什麼現在要做：</span>
            </div>
            <p className="text-[11px] text-[#6B21A8] line-clamp-2 leading-relaxed">
              {note.reason}
            </p>
          </div>
        )}

        {/* Checklist Progress Bar */}
        {totalSteps > 0 && (
          <div className="mb-3.5 bg-[#F8FAFD] p-2.5 rounded-xl border border-[#E9EEF6]">
            <div className="flex justify-between items-center text-[11px] text-[#5F6368] font-medium mb-1.5">
              <span>步驟進度</span>
              <span>
                {completedSteps} / {totalSteps}
              </span>
            </div>
            <div className="w-full bg-gray-200 h-1.5 rounded-full overflow-hidden">
              <div
                className="bg-emerald-500 h-full rounded-full transition-all"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          </div>
        )}

        {/* Minimal First Step Callout */}
        {note.minimalFirstStep && !note.completed && (
          <div className="mb-4 flex items-center justify-between p-2.5 bg-[#FFFBEB] border border-[#FEF3C7] rounded-xl text-xs">
            <div className="flex items-center gap-1.5 text-amber-900 overflow-hidden pr-2">
              <Zap className="w-3.5 h-3.5 text-amber-500 fill-amber-500 shrink-0" />
              <span className="truncate font-medium">{note.minimalFirstStep}</span>
            </div>
            <button
              onClick={() => onStartMinimalStep(note)}
              className="pill-btn shrink-0 px-2.5 py-1 text-[11px] font-bold bg-amber-500 hover:bg-amber-600 text-white shadow-2xs"
            >
              ⚡ 先做2分鐘
            </button>
          </div>
        )}
      </div>

      {/* Footer / Tags & ADHD Actions */}
      <div className="pt-3 border-t border-[#F0F4F9] flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-1 flex-wrap">
          {note.tags?.slice(0, 3).map((tg) => (
            <span
              key={tg}
              className="text-[11px] text-[#5F6368] hover:text-[#1F1F1F] font-medium"
            >
              {tg}
            </span>
          ))}
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={() => onStartSprint(note)}
            title="啟動 15 分鐘微衝刺"
            className="pill-btn px-2.5 py-1 text-[11px] font-medium bg-white border border-[#DCE3E9] text-[#0B57D0] hover:bg-[#F0F4F9] flex items-center gap-1"
          >
            <Flame className="w-3 h-3 text-[#0B57D0]" />
            <span>微衝刺</span>
          </button>

          <button
            onClick={() => onOpenDetail(note)}
            className="pill-btn px-2.5 py-1 text-[11px] font-medium bg-[#F0F4F9] hover:bg-[#E4EBF3] text-[#1F1F1F]"
          >
            詳情
          </button>
        </div>
      </div>
    </div>
  );
};
