import React from 'react';
import {
  X,
  Calendar,
  CheckCircle2,
  Circle,
  Zap,
  Flame,
  Edit3,
  Trash2,
  Lightbulb,
  Sparkles,
} from 'lucide-react';
import { NoteItem, StepItem } from '../types';
import { playCheckStepChime, playSuccessChime } from '../utils/audio';

interface NoteDetailModalProps {
  note: NoteItem | null;
  onClose: () => void;
  onEdit: (note: NoteItem) => void;
  onDelete: (id: string) => void;
  onUpdateSteps: (noteId: string, steps: StepItem[]) => void;
  onStartSprint: (note: NoteItem) => void;
  onStartMinimalStep: (note: NoteItem) => void;
  onToggleComplete: (id: string) => void;
}

export const NoteDetailModal: React.FC<NoteDetailModalProps> = ({
  note,
  onClose,
  onEdit,
  onDelete,
  onUpdateSteps,
  onStartSprint,
  onStartMinimalStep,
  onToggleComplete,
}) => {
  if (!note) return null;

  const handleToggleStep = (stepId: string) => {
    if (!note.steps) return;
    const updated = note.steps.map((st) =>
      st.id === stepId ? { ...st, completed: !st.completed } : st
    );
    onUpdateSteps(note.id, updated);
    playCheckStepChime();

    // If all steps completed, play success chime
    if (updated.every((s) => s.completed)) {
      playSuccessChime();
    }
  };

  const getCategoryBadge = () => {
    switch (note.type) {
      case 'academic':
        return (
          <span className="px-3 py-1 rounded-full text-xs font-semibold bg-[#FEF2F2] border border-[#FECACA] text-[#B91C1C]">
            🔴 學術課業
          </span>
        );
      case 'memo':
        return (
          <span className="px-3 py-1 rounded-full text-xs font-semibold bg-[#EFF6FF] border border-[#BFDBFE] text-[#1D4ED8]">
            🔵 備忘錄
          </span>
        );
      case 'flow':
        return (
          <span className="px-3 py-1 rounded-full text-xs font-semibold bg-[#F0FDF4] border border-[#BBF7D0] text-[#15803D]">
            🟢 計劃流
          </span>
        );
      case 'reason':
        return (
          <span className="px-3 py-1 rounded-full text-xs font-semibold bg-[#FAF5FF] border border-[#E9D5FF] text-[#7E22CE]">
            🟣 原因動機
          </span>
        );
    }
  };

  const totalSteps = note.steps?.length || 0;
  const completedSteps = note.steps?.filter((s) => s.completed).length || 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-3xl w-full max-w-2xl max-h-[90vh] shadow-[0_20px_50px_rgba(15,23,42,0.15)] border border-[#E9EEF6] overflow-y-auto my-auto animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-6 pb-4 flex items-center justify-between border-b border-[#F0F4F9]">
          <div className="flex items-center gap-2 flex-wrap">
            {getCategoryBadge()}
            {note.energyLevel && (
              <span
                className={`px-2.5 py-0.5 rounded-full text-xs font-medium border ${
                  note.energyLevel === 'high'
                    ? 'bg-amber-50 border-amber-200 text-amber-800'
                    : 'bg-sky-50 border-sky-200 text-sky-800'
                }`}
              >
                {note.energyLevel === 'high' ? '🔋 高能量燒腦' : '🪫 低能量無腦'}
              </span>
            )}
            {note.dueDate && (
              <span className="flex items-center gap-1 text-xs text-[#5F6368] px-2.5 py-0.5 rounded-full bg-[#F0F4F9]">
                <Calendar className="w-3.5 h-3.5" />
                <span>{note.dueDate}</span>
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onEdit(note)}
              className="p-2 rounded-full hover:bg-gray-100 text-[#5F6368] transition-colors"
              title="編輯"
            >
              <Edit3 className="w-4 h-4" />
            </button>
            <button
              onClick={() => {
                onDelete(note.id);
                onClose();
              }}
              className="p-2 rounded-full hover:bg-red-50 text-red-500 transition-colors"
              title="刪除"
            >
              <Trash2 className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-full hover:bg-gray-100 text-[#5F6368] transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Body Content */}
        <div className="p-6 sm:p-8 space-y-6">
          {/* Title with complete checkbox */}
          <div className="flex items-start gap-3">
            <button
              onClick={() => onToggleComplete(note.id)}
              className="mt-1 text-gray-400 hover:text-emerald-600 transition-colors"
            >
              {note.completed ? (
                <CheckCircle2 className="w-6 h-6 text-emerald-600 fill-emerald-50" />
              ) : (
                <Circle className="w-6 h-6 text-gray-300 hover:text-emerald-500" />
              )}
            </button>

            <div>
              <h2
                className={`text-xl sm:text-2xl font-bold text-[#1F1F1F] leading-snug ${
                  note.completed ? 'line-through text-gray-400' : ''
                }`}
              >
                {note.title}
              </h2>
              <p className="text-xs text-[#5F6368] mt-1">
                建立於 {new Date(note.createdAt).toLocaleString('zh-TW', { dateStyle: 'medium', timeStyle: 'short' })}
              </p>
            </div>
          </div>

          {/* Detailed Content */}
          {note.content && (
            <div className="bg-[#F8FAFD] p-5 rounded-2xl border border-[#E9EEF6] text-sm text-[#1F1F1F] leading-relaxed whitespace-pre-wrap">
              {note.content}
            </div>
          )}

          {/* 🟣 Purple Reason Box (Internal Motivation for ADHD) */}
          {note.reason && (
            <div className="bg-[#FAF5FF] border border-[#E9D5FF] rounded-2xl p-5">
              <div className="flex items-center gap-2 text-xs font-bold text-[#7E22CE] mb-2">
                <Lightbulb className="w-4 h-4 text-purple-600" />
                <span>內在動機（為什麼當下必須做這件事？）</span>
              </div>
              <p className="text-sm text-[#6B21A8] leading-relaxed">
                {note.reason}
              </p>
            </div>
          )}

          {/* ⚡ Minimal First Step Action Banner */}
          {note.minimalFirstStep && (
            <div className="bg-[#FFFBEB] border border-[#FEF3C7] rounded-2xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <div className="flex items-center gap-1.5 text-xs font-bold text-amber-900 mb-1">
                  <Zap className="w-4 h-4 text-amber-500 fill-amber-500" />
                  <span>⚡ 最小第一步（2 分鐘破冰微行動）</span>
                </div>
                <p className="text-sm font-semibold text-amber-950">
                  {note.minimalFirstStep}
                </p>
              </div>
              <button
                onClick={() => {
                  onClose();
                  onStartMinimalStep(note);
                }}
                className="pill-btn px-4 py-2 bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs shadow-xs shrink-0"
              >
                全螢幕聚焦此步驟
              </button>
            </div>
          )}

          {/* 🟢 Action Steps Checklist */}
          {totalSteps > 0 && (
            <div>
              <div className="flex justify-between items-center mb-3">
                <h4 className="text-sm font-bold text-[#1F1F1F]">
                  🟢 計劃步驟清單 ({completedSteps}/{totalSteps})
                </h4>
              </div>

              <div className="space-y-2">
                {note.steps?.map((st) => (
                  <div
                    key={st.id}
                    onClick={() => handleToggleStep(st.id)}
                    className={`flex items-center gap-3 p-3 rounded-2xl border transition-all cursor-pointer ${
                      st.completed
                        ? 'bg-emerald-50/40 border-emerald-200 text-gray-400'
                        : 'bg-white border-[#E9EEF6] hover:bg-[#F8FAFD] text-[#1F1F1F]'
                    }`}
                  >
                    {st.completed ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                    ) : (
                      <Circle className="w-5 h-5 text-gray-300 shrink-0" />
                    )}
                    <span
                      className={`text-sm ${
                        st.completed ? 'line-through' : 'font-medium'
                      }`}
                    >
                      {st.text}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Tags */}
          {note.tags && note.tags.length > 0 && (
            <div className="flex flex-wrap gap-1.5 pt-2">
              {note.tags.map((tg) => (
                <span
                  key={tg}
                  className="px-3 py-1 rounded-full text-xs bg-[#F0F4F9] text-[#5F6368] font-medium"
                >
                  {tg}
                </span>
              ))}
            </div>
          )}
        </div>

        {/* Bottom Actions Bar */}
        <div className="p-6 bg-[#F8FAFD] border-t border-[#F0F4F9] flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                onClose();
                onStartSprint(note);
              }}
              className="pill-btn px-4 py-2.5 bg-[#0B57D0] hover:bg-[#0842A0] text-white text-xs font-semibold flex items-center gap-2 shadow-xs"
            >
              <Flame className="w-4 h-4 fill-white" />
              <span>啟動 15 分鐘微衝刺</span>
            </button>

            {note.minimalFirstStep && (
              <button
                onClick={() => {
                  onClose();
                  onStartMinimalStep(note);
                }}
                className="pill-btn px-4 py-2.5 bg-white border border-[#DCE3E9] hover:bg-[#F0F4F9] text-[#1F1F1F] text-xs font-semibold flex items-center gap-2"
              >
                <Zap className="w-4 h-4 text-amber-500 fill-amber-500" />
                <span>2 分鐘破冰模式</span>
              </button>
            )}
          </div>

          <button
            onClick={onClose}
            className="pill-btn px-5 py-2.5 bg-white border border-[#DCE3E9] text-xs text-[#5F6368] hover:bg-[#F0F4F9]"
          >
            關閉
          </button>
        </div>
      </div>
    </div>
  );
};
