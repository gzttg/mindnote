import React, { useState } from 'react';
import { Search, Star, Filter, Plus, Sparkles } from 'lucide-react';
import { NoteItem, NoteType } from '../types';
import { NoteCard } from './NoteCard';
import { PRESET_TAGS } from '../data/defaultData';

interface NotesListViewProps {
  notes: NoteItem[];
  forcedType?: NoteType | null;
  onToggleComplete: (id: string) => void;
  onToggleStar: (id: string) => void;
  onDeleteNote: (id: string) => void;
  onEditNote: (note: NoteItem) => void;
  onOpenDetail: (note: NoteItem) => void;
  onStartSprint: (note: NoteItem) => void;
  onStartMinimalStep: (note: NoteItem) => void;
  onOpenNewModal: (type?: NoteType) => void;
}

export const NotesListView: React.FC<NotesListViewProps> = ({
  notes,
  forcedType = null,
  onToggleComplete,
  onToggleStar,
  onDeleteNote,
  onEditNote,
  onOpenDetail,
  onStartSprint,
  onStartMinimalStep,
  onOpenNewModal,
}) => {
  const [selectedType, setSelectedType] = useState<NoteType | 'all'>(
    forcedType || 'all'
  );
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTag, setSelectedTag] = useState<string | null>(null);
  const [onlyStarred, setOnlyStarred] = useState(false);
  const [statusFilter, setStatusFilter] = useState<'all' | 'pending' | 'completed'>('all');

  // Collect all unique tags from current notes
  const allTags = Array.from(
    new Set([...PRESET_TAGS, ...notes.flatMap((n) => n.tags || [])])
  );

  const effectiveType = forcedType || selectedType;

  // Filter notes
  const filteredNotes = notes.filter((note) => {
    // Type filter
    if (effectiveType !== 'all' && note.type !== effectiveType) return false;

    // Starred filter
    if (onlyStarred && !note.starred) return false;

    // Status filter
    if (statusFilter === 'pending' && note.completed) return false;
    if (statusFilter === 'completed' && !note.completed) return false;

    // Tag filter
    if (selectedTag && !note.tags?.includes(selectedTag)) return false;

    // Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchTitle = note.title.toLowerCase().includes(q);
      const matchContent = note.content.toLowerCase().includes(q);
      const matchReason = note.reason?.toLowerCase().includes(q);
      const matchMinimal = note.minimalFirstStep?.toLowerCase().includes(q);
      const matchTag = note.tags?.some((t) => t.toLowerCase().includes(q));
      if (!matchTitle && !matchContent && !matchReason && !matchMinimal && !matchTag) {
        return false;
      }
    }

    return true;
  });

  const getPageTitle = () => {
    switch (forcedType) {
      case 'academic':
        return '🎓 學術課業專區';
      case 'memo':
        return '📌 備忘與生活提醒';
      case 'flow':
        return '🟢 計劃流與目標追蹤';
      case 'reason':
        return '🟣 核心原因與動機筆記';
      default:
        return '🔍 搜尋與分類總覽';
    }
  };

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      {/* Title & Quick Add Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#1F1F1F] tracking-tight">
            {getPageTitle()}
          </h1>
          <p className="text-xs text-[#5F6368] mt-1">
            共 {filteredNotes.length} 則筆記 · 篩選符合條件的行動與記錄
          </p>
        </div>

        <button
          onClick={() => onOpenNewModal(forcedType || undefined)}
          className="pill-btn px-5 py-2.5 bg-[#0B57D0] hover:bg-[#0842A0] text-white text-xs font-semibold flex items-center gap-2 shadow-xs shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>在此分類新增</span>
        </button>
      </div>

      {/* Filter Tabs & Search Bar */}
      <div className="space-y-3">
        {/* Category Pills (only if not forcedType) */}
        {!forcedType && (
          <div className="flex items-center gap-1.5 flex-wrap">
            <button
              onClick={() => setSelectedType('all')}
              className={`pill-btn px-4 py-2 text-xs font-semibold rounded-full ${
                selectedType === 'all'
                  ? 'bg-[#1F1F1F] text-white'
                  : 'bg-white border border-[#DCE3E9] text-[#5F6368] hover:bg-[#F0F4F9]'
              }`}
            >
              全部分類
            </button>
            <button
              onClick={() => setSelectedType('academic')}
              className={`pill-btn px-4 py-2 text-xs font-semibold rounded-full ${
                selectedType === 'academic'
                  ? 'bg-[#FEF2F2] border border-[#FECACA] text-[#B91C1C]'
                  : 'bg-white border border-[#DCE3E9] text-[#5F6368] hover:bg-[#F0F4F9]'
              }`}
            >
              🔴 學術課業
            </button>
            <button
              onClick={() => setSelectedType('memo')}
              className={`pill-btn px-4 py-2 text-xs font-semibold rounded-full ${
                selectedType === 'memo'
                  ? 'bg-[#EFF6FF] border border-[#BFDBFE] text-[#1D4ED8]'
                  : 'bg-white border border-[#DCE3E9] text-[#5F6368] hover:bg-[#F0F4F9]'
              }`}
            >
              🔵 備忘錄
            </button>
            <button
              onClick={() => setSelectedType('flow')}
              className={`pill-btn px-4 py-2 text-xs font-semibold rounded-full ${
                selectedType === 'flow'
                  ? 'bg-[#F0FDF4] border border-[#BBF7D0] text-[#15803D]'
                  : 'bg-white border border-[#DCE3E9] text-[#5F6368] hover:bg-[#F0F4F9]'
              }`}
            >
              🟢 計劃流
            </button>
            <button
              onClick={() => setSelectedType('reason')}
              className={`pill-btn px-4 py-2 text-xs font-semibold rounded-full ${
                selectedType === 'reason'
                  ? 'bg-[#FAF5FF] border border-[#E9D5FF] text-[#7E22CE]'
                  : 'bg-white border border-[#DCE3E9] text-[#5F6368] hover:bg-[#F0F4F9]'
              }`}
            >
              🟣 原因動機
            </button>
          </div>
        )}

        {/* Gemini Rounded Search Bar & Filter Options */}
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="flex-1 relative">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="搜尋標題、內容、原因、步驟或標籤..."
              className="w-full pl-10 pr-4 py-2.5 rounded-full bg-white border border-[#E9EEF6] text-sm text-[#1F1F1F] placeholder:text-[#9AA0A6] shadow-xs focus:border-[#A8C7FA] focus:ring-2 focus:ring-blue-100 outline-none"
            />
            <Search className="w-4 h-4 text-gray-400 absolute left-3.5 top-3" />
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setOnlyStarred(!onlyStarred)}
              className={`pill-btn px-3.5 py-2 text-xs font-semibold rounded-full flex items-center gap-1.5 transition-all ${
                onlyStarred
                  ? 'bg-amber-100 text-amber-900 border border-amber-300'
                  : 'bg-white border border-[#DCE3E9] text-[#5F6368] hover:bg-[#F0F4F9]'
              }`}
            >
              <Star className={`w-3.5 h-3.5 ${onlyStarred ? 'fill-amber-500 text-amber-500' : ''}`} />
              <span>僅看星標</span>
            </button>

            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as any)}
              className="px-3.5 py-2 rounded-full bg-white border border-[#DCE3E9] text-xs text-[#5F6368] font-semibold outline-none hover:bg-[#F0F4F9] cursor-pointer"
            >
              <option value="all">狀態：全部</option>
              <option value="pending">僅進行中</option>
              <option value="completed">僅已完成</option>
            </select>
          </div>
        </div>

        {/* Tags Cloud Filter */}
        <div className="flex items-center gap-1.5 flex-wrap pt-1 text-xs">
          <span className="text-[11px] text-[#5F6368] mr-1">熱門標籤:</span>
          {allTags.map((tg) => {
            const isSelected = selectedTag === tg;
            return (
              <button
                key={tg}
                onClick={() => setSelectedTag(isSelected ? null : tg)}
                className={`px-2.5 py-1 rounded-full text-[11px] font-medium transition-all ${
                  isSelected
                    ? 'bg-blue-600 text-white shadow-2xs'
                    : 'bg-[#F0F4F9] text-[#5F6368] hover:bg-[#E4EBF3]'
                }`}
              >
                {tg}
              </button>
            );
          })}
          {selectedTag && (
            <button
              onClick={() => setSelectedTag(null)}
              className="text-[11px] text-red-600 hover:underline ml-2"
            >
              清除標籤篩選
            </button>
          )}
        </div>
      </div>

      {/* Cards Grid */}
      {filteredNotes.length === 0 ? (
        <div className="bg-white border border-[#E9EEF6] rounded-3xl p-12 text-center text-xs text-[#5F6368] space-y-3">
          <Sparkles className="w-8 h-8 text-blue-400 mx-auto" />
          <p className="text-sm font-semibold text-[#1F1F1F]">找不到符合條件的筆記</p>
          <p className="text-gray-400">試試清除篩選條件，或點擊右上角新增筆記。</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredNotes.map((note) => (
            <NoteCard
              key={note.id}
              note={note}
              onToggleComplete={onToggleComplete}
              onToggleStar={onToggleStar}
              onDelete={onDeleteNote}
              onEdit={onEditNote}
              onOpenDetail={onOpenDetail}
              onStartSprint={onStartSprint}
              onStartMinimalStep={onStartMinimalStep}
            />
          ))}
        </div>
      )}
    </div>
  );
};
