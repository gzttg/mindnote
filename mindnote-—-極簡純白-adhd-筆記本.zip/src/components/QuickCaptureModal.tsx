import React, { useState, useEffect } from 'react';
import {
  X,
  Plus,
  Trash2,
  Dice5,
  Calendar as CalendarIcon,
  Zap,
  Mic,
  MicOff,
  Sparkles,
} from 'lucide-react';
import { NoteItem, NoteType, EnergyLevel, StepItem, ReasonCard } from '../types';
import { PRESET_TAGS } from '../data/defaultData';
import { createSpeechHelper } from '../utils/speech';
import { playCheckStepChime } from '../utils/audio';

interface QuickCaptureModalProps {
  isOpen: boolean;
  initialDraft?: string;
  initialType?: NoteType;
  editingNote?: NoteItem | null;
  reasons: ReasonCard[];
  onClose: () => void;
  onSave: (note: Omit<NoteItem, 'id' | 'createdAt'> & { id?: string }) => void;
}

export const QuickCaptureModal: React.FC<QuickCaptureModalProps> = ({
  isOpen,
  initialDraft = '',
  initialType = 'academic',
  editingNote,
  reasons,
  onClose,
  onSave,
}) => {
  const [type, setType] = useState<NoteType>(initialType);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [minimalFirstStep, setMinimalFirstStep] = useState('');
  const [reason, setReason] = useState('');
  const [reasonId, setReasonId] = useState<string | undefined>(undefined);
  const [energyLevel, setEnergyLevel] = useState<EnergyLevel>('high');
  const [dueDate, setDueDate] = useState('');
  const [tags, setTags] = useState<string[]>(['#學術']);
  const [customTagInput, setCustomTagInput] = useState('');
  const [steps, setSteps] = useState<StepItem[]>([]);
  const [newStepText, setNewStepText] = useState('');
  const [showReasonPicker, setShowReasonPicker] = useState(false);
  const [isListening, setIsListening] = useState(false);

  const speechHelper = React.useMemo(() => createSpeechHelper(), []);

  useEffect(() => {
    if (editingNote) {
      setType(editingNote.type);
      setTitle(editingNote.title);
      setContent(editingNote.content);
      setMinimalFirstStep(editingNote.minimalFirstStep || '');
      setReason(editingNote.reason || '');
      setReasonId(editingNote.reasonId);
      setEnergyLevel(editingNote.energyLevel || 'high');
      setDueDate(editingNote.dueDate || '');
      setTags(editingNote.tags || []);
      setSteps(editingNote.steps || []);
    } else {
      setType(initialType);
      setTitle('');
      setContent(initialDraft);
      setMinimalFirstStep('');
      setReason('');
      setReasonId(undefined);
      setEnergyLevel(initialType === 'memo' ? 'low' : 'high');
      setDueDate(new Date().toISOString().split('T')[0]);
      setTags(initialType === 'academic' ? ['#學術'] : initialType === 'flow' ? ['#目標'] : ['#生活']);
      setSteps([]);
    }
  }, [editingNote, initialDraft, initialType, isOpen]);

  if (!isOpen) return null;

  const handleAddStep = () => {
    if (!newStepText.trim()) return;
    setSteps([
      ...steps,
      {
        id: `step-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        text: newStepText.trim(),
        completed: false,
      },
    ]);
    setNewStepText('');
    playCheckStepChime();
  };

  const handleRemoveStep = (id: string) => {
    setSteps(steps.filter((s) => s.id !== id));
  };

  const handleAddCustomTag = () => {
    let t = customTagInput.trim();
    if (!t) return;
    if (!t.startsWith('#')) t = `#${t}`;
    if (!tags.includes(t)) {
      setTags([...tags, t]);
    }
    setCustomTagInput('');
  };

  const handleTogglePresetTag = (tag: string) => {
    if (tags.includes(tag)) {
      setTags(tags.filter((t) => t !== tag));
    } else {
      setTags([...tags, tag]);
    }
  };

  const handleSelectReasonCard = (rc: ReasonCard) => {
    setReason(`${rc.title}：${rc.benefit}`);
    setReasonId(rc.id);
    setShowReasonPicker(false);
  };

  const handleRandomDrawReason = () => {
    if (reasons.length === 0) return;
    const randomIdx = Math.floor(Math.random() * reasons.length);
    const chosen = reasons[randomIdx];
    handleSelectReasonCard(chosen);
  };

  const handleToggleVoice = () => {
    if (!speechHelper.isSupported) return;
    if (isListening) {
      setIsListening(false);
    } else {
      setIsListening(true);
      speechHelper.start(
        (transcript) => {
          setContent((prev) => (prev ? `${prev} ${transcript}` : transcript));
        },
        () => setIsListening(false),
        () => setIsListening(false)
      );
    }
  };

  const setRelativeDate = (days: number) => {
    const d = new Date();
    d.setDate(d.getDate() + days);
    setDueDate(d.toISOString().split('T')[0]);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Auto generate title from first 15 chars of content if left empty
    let finalTitle = title.trim();
    if (!finalTitle) {
      finalTitle = content.trim().slice(0, 15) || '無標題記錄';
    }

    onSave({
      id: editingNote?.id,
      type,
      title: finalTitle,
      content: content.trim(),
      minimalFirstStep: minimalFirstStep.trim(),
      reason: reason.trim(),
      reasonId,
      energyLevel,
      dueDate: dueDate || undefined,
      tags,
      steps,
      completed: editingNote?.completed ?? false,
      starred: editingNote?.starred ?? false,
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-3xl w-full max-w-2xl max-h-[90vh] shadow-[0_20px_50px_rgba(15,23,42,0.15)] border border-[#E9EEF6] overflow-y-auto my-auto animate-in fade-in duration-200">
        {/* Header */}
        <div className="p-6 pb-4 flex items-center justify-between border-b border-[#F0F4F9]">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center">
              <Sparkles className="w-4 h-4" />
            </div>
            <h2 className="text-lg font-bold text-[#1F1F1F]">
              {editingNote ? '編輯筆記與行動' : '快速捕捉 · 啟動行動'}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-[#F0F4F9] text-[#5F6368] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Four Pastel Type Selector Pills */}
          <div>
            <label className="block text-xs font-semibold text-[#5F6368] uppercase tracking-wider mb-2.5">
              選擇分類
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              <button
                type="button"
                onClick={() => setType('academic')}
                className={`py-2 px-3 rounded-full text-xs font-semibold border transition-all text-center ${
                  type === 'academic'
                    ? 'bg-[#FEF2F2] border-[#FECACA] text-[#B91C1C] ring-2 ring-red-200 ring-offset-1'
                    : 'bg-white border-[#DCE3E9] text-gray-600 hover:bg-[#F0F4F9]'
                }`}
              >
                🔴 學術課業
              </button>
              <button
                type="button"
                onClick={() => setType('memo')}
                className={`py-2 px-3 rounded-full text-xs font-semibold border transition-all text-center ${
                  type === 'memo'
                    ? 'bg-[#EFF6FF] border-[#BFDBFE] text-[#1D4ED8] ring-2 ring-blue-200 ring-offset-1'
                    : 'bg-white border-[#DCE3E9] text-gray-600 hover:bg-[#F0F4F9]'
                }`}
              >
                🔵 備忘錄
              </button>
              <button
                type="button"
                onClick={() => setType('flow')}
                className={`py-2 px-3 rounded-full text-xs font-semibold border transition-all text-center ${
                  type === 'flow'
                    ? 'bg-[#F0FDF4] border-[#BBF7D0] text-[#15803D] ring-2 ring-emerald-200 ring-offset-1'
                    : 'bg-white border-[#DCE3E9] text-gray-600 hover:bg-[#F0F4F9]'
                }`}
              >
                🟢 計劃流
              </button>
              <button
                type="button"
                onClick={() => setType('reason')}
                className={`py-2 px-3 rounded-full text-xs font-semibold border transition-all text-center ${
                  type === 'reason'
                    ? 'bg-[#FAF5FF] border-[#E9D5FF] text-[#7E22CE] ring-2 ring-purple-200 ring-offset-1'
                    : 'bg-white border-[#DCE3E9] text-gray-600 hover:bg-[#F0F4F9]'
                }`}
              >
                🟣 原因動機
              </button>
            </div>
          </div>

          {/* Title Input */}
          <div>
            <div className="flex justify-between items-center mb-1.5">
              <label className="text-xs font-semibold text-[#5F6368] uppercase tracking-wider">
                筆記標題
              </label>
              <span className="text-[11px] text-[#5F6368]">可留空，自動擷取前 15 字</span>
            </div>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="例如：完成分子生物學作業（第3章）"
              className="w-full px-4 py-2.5 rounded-2xl bg-white border border-[#DCE3E9] text-sm text-[#1F1F1F] focus:border-[#0B57D0] focus:ring-2 focus:ring-blue-100 outline-none transition-all"
            />
          </div>

          {/* Content & Voice Input */}
          <div>
            <div className="flex justify-between items-center mb-1.5">
              <label className="text-xs font-semibold text-[#5F6368] uppercase tracking-wider">
                詳細內容
              </label>
              {speechHelper.isSupported && (
                <button
                  type="button"
                  onClick={handleToggleVoice}
                  className={`flex items-center gap-1 text-xs px-2.5 py-1 rounded-full transition-colors ${
                    isListening
                      ? 'bg-red-500 text-white animate-pulse'
                      : 'text-[#0B57D0] hover:bg-blue-50'
                  }`}
                >
                  {isListening ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5" />}
                  <span>{isListening ? '聆聽中...' : '語音閃電輸入'}</span>
                </button>
              )}
            </div>
            <textarea
              rows={3}
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="寫下任何靈感、要求、作業細節或待辦事項..."
              className="w-full px-4 py-2.5 rounded-2xl bg-white border border-[#DCE3E9] text-sm text-[#1F1F1F] focus:border-[#0B57D0] focus:ring-2 focus:ring-blue-100 outline-none transition-all resize-none"
            />
          </div>

          {/* Minimal First Step (2-Minute Rule for ADHD) */}
          <div className="bg-[#FFFBEB] border border-[#FEF3C7] rounded-2xl p-4">
            <div className="flex items-center justify-between mb-1.5">
              <div className="flex items-center gap-1.5 text-xs font-bold text-[#92400E]">
                <Zap className="w-4 h-4 text-amber-500 fill-amber-500" />
                <span>⚡ 最小第一步（2 分鐘微行動）</span>
              </div>
              <span className="text-[11px] text-[#B45309]">打破啟動阻力，降低大腦焦慮</span>
            </div>
            <input
              type="text"
              value={minimalFirstStep}
              onChange={(e) => setMinimalFirstStep(e.target.value)}
              placeholder="例如：打開講義 PDF 翻到第 3 章第一頁、或是換上運動鞋"
              className="w-full px-3.5 py-2 rounded-xl bg-white border border-[#FDE68A] text-xs text-[#1F1F1F] placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-amber-300"
            />
          </div>

          {/* Why Section (Purple Pastel Motivation Box) */}
          <div className="bg-[#FAF5FF] border border-[#E9D5FF] rounded-2xl p-4">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-1.5 text-xs font-bold text-[#7E22CE]">
                <span>🟣 寫下原因（為什麼當下需要做這個？）</span>
              </div>
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={handleRandomDrawReason}
                  className="pill-btn flex items-center gap-1 px-2.5 py-1 text-[11px] bg-white border border-[#D8B4FE] text-[#7E22CE] hover:bg-[#F3E8FF] font-medium"
                >
                  <Dice5 className="w-3.5 h-3.5" />
                  <span>一鍵抽卡</span>
                </button>
                <button
                  type="button"
                  onClick={() => setShowReasonPicker(!showReasonPicker)}
                  className="pill-btn px-2.5 py-1 text-[11px] bg-white border border-[#D8B4FE] text-[#7E22CE] hover:bg-[#F3E8FF] font-medium"
                >
                  選取庫存原因
                </button>
              </div>
            </div>

            <textarea
              rows={2}
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="告訴我為什麼要做：是能帶來研究所申請加分？還是避免拖延導致後續嚴重焦慮？"
              className="w-full px-3.5 py-2 rounded-xl bg-white border border-[#E9D5FF] text-xs text-[#1F1F1F] placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-300 resize-none"
            />

            {/* Reason Drawer Popover */}
            {showReasonPicker && (
              <div className="mt-3 p-3 bg-white rounded-xl border border-[#E9D5FF] space-y-2 max-h-48 overflow-y-auto">
                <p className="text-[11px] font-semibold text-gray-500">點擊即掛載核心動機：</p>
                {reasons.map((r) => (
                  <div
                    key={r.id}
                    onClick={() => handleSelectReasonCard(r)}
                    className="p-2 rounded-lg hover:bg-[#FAF5FF] border border-transparent hover:border-[#E9D5FF] cursor-pointer text-xs transition-colors"
                  >
                    <div className="font-semibold text-[#7E22CE]">{r.title}</div>
                    <div className="text-[11px] text-gray-600 line-clamp-1">{r.benefit}</div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Action Steps Checklist Builder */}
          <div>
            <div className="flex justify-between items-center mb-2">
              <label className="text-xs font-semibold text-[#5F6368] uppercase tracking-wider">
                🟢 計劃步驟清單（選填）
              </label>
              <span className="text-[11px] text-[#5F6368]">拆解成微小動作</span>
            </div>

            <div className="flex gap-2 mb-2.5">
              <input
                type="text"
                value={newStepText}
                onChange={(e) => setNewStepText(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddStep();
                  }
                }}
                placeholder="輸入具體小步驟後按新增..."
                className="flex-1 px-3.5 py-2 rounded-xl bg-white border border-[#DCE3E9] text-xs text-[#1F1F1F] outline-none focus:border-[#0B57D0]"
              />
              <button
                type="button"
                onClick={handleAddStep}
                className="pill-btn px-4 py-2 bg-[#F0F4F9] hover:bg-[#E4EBF3] text-xs font-semibold text-[#1F1F1F]"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>

            {steps.length > 0 && (
              <div className="space-y-1.5 max-h-36 overflow-y-auto">
                {steps.map((st, idx) => (
                  <div
                    key={st.id}
                    className="flex items-center justify-between px-3 py-2 bg-[#F8FAFD] rounded-xl text-xs border border-[#E9EEF6]"
                  >
                    <span className="text-gray-400 font-mono text-[11px] mr-2">0{idx + 1}.</span>
                    <span className="flex-1 text-[#1F1F1F] truncate">{st.text}</span>
                    <button
                      type="button"
                      onClick={() => handleRemoveStep(st.id)}
                      className="text-gray-400 hover:text-red-500 p-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Energy & Date Controls */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Energy Level */}
            <div>
              <label className="block text-xs font-semibold text-[#5F6368] uppercase tracking-wider mb-2">
                大腦能量需求
              </label>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setEnergyLevel('high')}
                  className={`flex-1 py-2 rounded-full text-xs font-medium border transition-all text-center ${
                    energyLevel === 'high'
                      ? 'bg-amber-50 border-amber-300 text-amber-800 font-bold'
                      : 'bg-white border-[#DCE3E9] text-gray-600 hover:bg-gray-50'
                  }`}
                >
                  🔋 高能量燒腦
                </button>
                <button
                  type="button"
                  onClick={() => setEnergyLevel('low')}
                  className={`flex-1 py-2 rounded-full text-xs font-medium border transition-all text-center ${
                    energyLevel === 'low'
                      ? 'bg-sky-50 border-sky-300 text-sky-800 font-bold'
                      : 'bg-white border-[#DCE3E9] text-gray-600 hover:bg-gray-50'
                  }`}
                >
                  🪫 低能量無腦
                </button>
              </div>
            </div>

            {/* Due Date & Shortcuts */}
            <div>
              <label className="block text-xs font-semibold text-[#5F6368] uppercase tracking-wider mb-2">
                目標日期（防時間盲區）
              </label>
              <div className="flex items-center gap-2">
                <div className="relative flex-1">
                  <input
                    type="date"
                    value={dueDate}
                    onChange={(e) => setDueDate(e.target.value)}
                    className="w-full pl-8 pr-3 py-1.5 rounded-full bg-white border border-[#DCE3E9] text-xs text-[#1F1F1F] outline-none focus:border-[#0B57D0]"
                  />
                  <CalendarIcon className="w-3.5 h-3.5 text-gray-400 absolute left-3 top-2.5" />
                </div>
                <button
                  type="button"
                  onClick={() => setRelativeDate(0)}
                  className="px-2.5 py-1.5 bg-[#F0F4F9] hover:bg-[#E4EBF3] rounded-full text-[11px] text-gray-700"
                >
                  今天
                </button>
                <button
                  type="button"
                  onClick={() => setRelativeDate(1)}
                  className="px-2.5 py-1.5 bg-[#F0F4F9] hover:bg-[#E4EBF3] rounded-full text-[11px] text-gray-700"
                >
                  明天
                </button>
              </div>
            </div>
          </div>

          {/* Tags Selector */}
          <div>
            <label className="block text-xs font-semibold text-[#5F6368] uppercase tracking-wider mb-2">
              # 主題標籤
            </label>
            <div className="flex flex-wrap gap-1.5 mb-2.5">
              {PRESET_TAGS.map((pt) => {
                const isSelected = tags.includes(pt);
                return (
                  <button
                    key={pt}
                    type="button"
                    onClick={() => handleTogglePresetTag(pt)}
                    className={`px-3 py-1 rounded-full text-xs font-medium transition-all ${
                      isSelected
                        ? 'bg-[#1F1F1F] text-white'
                        : 'bg-white border border-[#DCE3E9] text-[#5F6368] hover:bg-[#F0F4F9]'
                    }`}
                  >
                    {pt}
                  </button>
                );
              })}
            </div>
            <div className="flex gap-2">
              <input
                type="text"
                value={customTagInput}
                onChange={(e) => setCustomTagInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddCustomTag();
                  }
                }}
                placeholder="自訂標籤 (例如: #期中考)..."
                className="w-48 px-3 py-1 rounded-full bg-white border border-[#DCE3E9] text-xs text-[#1F1F1F] outline-none"
              />
              <button
                type="button"
                onClick={handleAddCustomTag}
                className="pill-btn px-3 py-1 bg-white border border-[#DCE3E9] hover:bg-[#F0F4F9] text-xs text-gray-700"
              >
                新增
              </button>
            </div>
          </div>

          {/* Actions Bottom Bar */}
          <div className="pt-4 border-t border-[#F0F4F9] flex justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="pill-btn px-5 py-2.5 text-sm bg-white border border-[#DCE3E9] text-[#5F6368] hover:bg-[#F0F4F9]"
            >
              取消
            </button>
            <button
              type="submit"
              className="pill-btn px-6 py-2.5 text-sm bg-[#0B57D0] hover:bg-[#0842A0] text-white font-medium shadow-xs"
            >
              {editingNote ? '儲存變更' : '✨ 儲存並建立'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
