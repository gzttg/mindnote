import React, { useState } from 'react';
import { Lightbulb, Plus, Trash2, Sparkles, TrendingUp, AlertTriangle } from 'lucide-react';
import { ReasonCard } from '../types';

interface ReasonLibraryViewProps {
  reasons: ReasonCard[];
  onAddReason: (reason: Omit<ReasonCard, 'id' | 'timesUsed'>) => void;
  onDeleteReason: (id: string) => void;
}

export const ReasonLibraryView: React.FC<ReasonLibraryViewProps> = ({
  reasons,
  onAddReason,
  onDeleteReason,
}) => {
  const [showAddForm, setShowAddForm] = useState(false);
  const [title, setTitle] = useState('');
  const [benefit, setBenefit] = useState('');
  const [consequence, setConsequence] = useState('');
  const [tagInput, setTagInput] = useState('');

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !benefit.trim()) return;

    const tags = tagInput
      .split(/[\s,]+/)
      .filter((t) => t.trim().length > 0)
      .map((t) => (t.startsWith('#') ? t : `#${t}`));

    onAddReason({
      title: title.trim(),
      benefit: benefit.trim(),
      consequence: consequence.trim(),
      tags: tags.length > 0 ? tags : ['#核心動機'],
    });

    setTitle('');
    setBenefit('');
    setConsequence('');
    setTagInput('');
    setShowAddForm(false);
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="p-1.5 rounded-full bg-purple-100 text-purple-700">
              <Lightbulb className="w-5 h-5" />
            </span>
            <h1 className="text-2xl font-bold text-[#1F1F1F]">💡 核心原因庫（動機銀行）</h1>
          </div>
          <p className="text-xs text-[#5F6368]">
            「ADHD 不是缺乏能力，而是缺乏當下的動機刺激。」集中儲存你的核心原因，快速抽卡破除拖延。
          </p>
        </div>

        <button
          onClick={() => setShowAddForm(!showAddForm)}
          className="pill-btn px-5 py-2.5 bg-[#0B57D0] hover:bg-[#0842A0] text-white text-xs font-semibold flex items-center gap-2 shadow-xs shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>新增動機卡片</span>
        </button>
      </div>

      {/* Add New Reason Form */}
      {showAddForm && (
        <form
          onSubmit={handleCreate}
          className="bg-white border border-[#E9D5FF] rounded-3xl p-6 shadow-md space-y-4 animate-in fade-in"
        >
          <div className="flex items-center gap-2 text-sm font-bold text-[#7E22CE]">
            <Sparkles className="w-4 h-4" />
            <span>建立新的核心動機</span>
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#5F6368] mb-1">動機主題</label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="例如：提升體能與多巴胺、申請研究所加分..."
              className="w-full px-4 py-2 rounded-xl border border-[#DCE3E9] text-xs outline-none focus:border-purple-500"
              required
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-emerald-700 mb-1 flex items-center gap-1">
                <TrendingUp className="w-3.5 h-3.5" />
                <span>做到的好處（正向多巴胺激勵）</span>
              </label>
              <textarea
                rows={2}
                value={benefit}
                onChange={(e) => setBenefit(e.target.value)}
                placeholder="做這件事能帶給我什麼具體好處與長期回報？"
                className="w-full px-3 py-2 rounded-xl border border-emerald-200 text-xs outline-none focus:border-emerald-500 resize-none bg-emerald-50/20"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-amber-800 mb-1 flex items-center gap-1">
                <AlertTriangle className="w-3.5 h-3.5" />
                <span>拖延的代價（危機感意識喚醒）</span>
              </label>
              <textarea
                rows={2}
                value={consequence}
                onChange={(e) => setConsequence(e.target.value)}
                placeholder="如果不做，會造成什麼焦慮、內耗或實質損失？"
                className="w-full px-3 py-2 rounded-xl border border-amber-200 text-xs outline-none focus:border-amber-500 resize-none bg-amber-50/20"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#5F6368] mb-1">標籤（以空格分隔）</label>
            <input
              type="text"
              value={tagInput}
              onChange={(e) => setTagInput(e.target.value)}
              placeholder="#健身 #專注力 #學術"
              className="w-full px-4 py-2 rounded-xl border border-[#DCE3E9] text-xs outline-none focus:border-purple-500"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="pill-btn px-4 py-2 text-xs bg-gray-100 text-gray-600 hover:bg-gray-200"
            >
              取消
            </button>
            <button
              type="submit"
              className="pill-btn px-5 py-2 text-xs bg-[#7E22CE] hover:bg-[#6B21A8] text-white font-semibold"
            >
              儲存至動機銀行
            </button>
          </div>
        </form>
      )}

      {/* Grid of Reasons */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {reasons.map((rc) => (
          <div
            key={rc.id}
            className="card-hover-subtle bg-white border border-[#E9EEF6] rounded-3xl p-6 shadow-[0_4px_20px_rgba(15,23,42,0.03)] flex flex-col justify-between"
          >
            <div>
              <div className="flex justify-between items-start mb-3">
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-[#FAF5FF] border border-[#E9D5FF] text-[#7E22CE]">
                  🟣 {rc.title}
                </span>
                <button
                  onClick={() => onDeleteReason(rc.id)}
                  className="p-1 text-gray-300 hover:text-red-500 transition-colors"
                  title="刪除此原因"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>

              {/* Benefit */}
              <div className="mb-3 p-3 bg-emerald-50/50 rounded-2xl border border-emerald-100 text-xs">
                <div className="flex items-center gap-1.5 font-bold text-emerald-800 mb-1">
                  <TrendingUp className="w-3.5 h-3.5" />
                  <span>好處（好在哪裡）：</span>
                </div>
                <p className="text-emerald-950 leading-relaxed text-[11px]">{rc.benefit}</p>
              </div>

              {/* Consequence */}
              {rc.consequence && (
                <div className="mb-3 p-3 bg-amber-50/40 rounded-2xl border border-amber-100 text-xs">
                  <div className="flex items-center gap-1.5 font-bold text-amber-900 mb-1">
                    <AlertTriangle className="w-3.5 h-3.5" />
                    <span>代價（拖延嚴重性）：</span>
                  </div>
                  <p className="text-amber-950 leading-relaxed text-[11px]">{rc.consequence}</p>
                </div>
              )}
            </div>

            <div className="pt-3 border-t border-gray-100 flex items-center justify-between text-[11px] text-[#5F6368]">
              <div className="flex gap-1.5 flex-wrap">
                {rc.tags?.map((t) => (
                  <span key={t} className="text-purple-600 font-medium">
                    {t}
                  </span>
                ))}
              </div>
              <span>已引用 {rc.timesUsed || 0} 次</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
