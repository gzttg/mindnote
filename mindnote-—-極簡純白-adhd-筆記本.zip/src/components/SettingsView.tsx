import React, { useRef, useState } from 'react';
import {
  Settings,
  HardDrive,
  Download,
  Upload,
  FileCode2,
  RotateCcw,
  CheckCircle2,
  AlertCircle,
  Sparkles,
} from 'lucide-react';
import { NoteItem, ReasonCard } from '../types';
import { downloadStandaloneHtmlFile } from '../utils/standaloneHtmlGenerator';

interface SettingsViewProps {
  notes: NoteItem[];
  reasons: ReasonCard[];
  onImportData: (notes: NoteItem[], reasons: ReasonCard[]) => void;
  onResetDefault: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  notes,
  reasons,
  onImportData,
  onResetDefault,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Compute localStorage usage in KB
  const computeStorageKB = () => {
    try {
      let totalLength = 0;
      for (const key in localStorage) {
        if (Object.prototype.hasOwnProperty.call(localStorage, key)) {
          totalLength += (localStorage[key].length + key.length) * 2;
        }
      }
      return (totalLength / 1024).toFixed(2);
    } catch {
      return '0.00';
    }
  };

  const handleExportJson = () => {
    const backupData = {
      version: 1,
      appName: 'MindNote',
      exportedAt: new Date().toISOString(),
      notes,
      reasons,
    };
    const jsonStr = JSON.stringify(backupData, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `MindNote_Backup_${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showSuccess('JSON 資料備份檔已成功下載！');
  };

  const handleImportJson = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        const parsed = JSON.parse(text);

        if (Array.isArray(parsed.notes)) {
          onImportData(parsed.notes, parsed.reasons || []);
          showSuccess(`成功匯入 ${parsed.notes.length} 則筆記！`);
        } else if (Array.isArray(parsed)) {
          onImportData(parsed, []);
          showSuccess(`成功匯入 ${parsed.length} 則筆記！`);
        } else {
          setErrorMsg('無效的備份檔案格式');
        }
      } catch (err) {
        setErrorMsg('解析 JSON 檔案失敗，請檢查檔案內容');
      }
    };
    reader.readAsText(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleDownloadStandaloneHtml = () => {
    downloadStandaloneHtmlFile(notes, reasons);
    showSuccess('獨立單檔案 index.html 已下載！雙擊即可在無網路環境離線直接運行。');
  };

  const showSuccess = (msg: string) => {
    setSuccessMsg(msg);
    setTimeout(() => setSuccessMsg(null), 4000);
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 mb-1">
          <span className="p-1.5 rounded-full bg-slate-100 text-slate-700">
            <Settings className="w-5 h-5" />
          </span>
          <h1 className="text-2xl font-bold text-[#1F1F1F]">⚙️ 系統設定與離線備份</h1>
        </div>
        <p className="text-xs text-[#5F6368]">
          您的資料完全保留在本地瀏覽器中，無後端洩漏隱私風險。隨時匯出備份或下載單一離線網頁檔案。
        </p>
      </div>

      {/* Notifications */}
      {successMsg && (
        <div className="flex items-center gap-2 p-4 bg-emerald-50 border border-emerald-200 rounded-2xl text-xs text-emerald-800 font-semibold animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          <span>{successMsg}</span>
        </div>
      )}

      {errorMsg && (
        <div className="flex items-center gap-2 p-4 bg-red-50 border border-red-200 rounded-2xl text-xs text-red-800 font-semibold animate-in fade-in">
          <AlertCircle className="w-4 h-4 text-red-600" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* Storage Information Card */}
      <div className="bg-white border border-[#E9EEF6] rounded-3xl p-6 shadow-[0_4px_20px_rgba(15,23,42,0.03)] space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-gray-100">
          <div className="flex items-center gap-2">
            <HardDrive className="w-4 h-4 text-[#0B57D0]" />
            <h2 className="text-sm font-bold text-[#1F1F1F]">本地儲存空間佔用</h2>
          </div>
          <span className="font-mono text-xs font-semibold px-2.5 py-1 rounded-full bg-blue-50 text-[#0B57D0]">
            {computeStorageKB()} KB 已使用
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div className="p-3 bg-[#F8FAFD] rounded-2xl border border-[#E9EEF6]">
            <p className="text-[#5F6368]">總筆記數</p>
            <p className="text-lg font-bold text-[#1F1F1F] mt-1">{notes.length}</p>
          </div>
          <div className="p-3 bg-[#F8FAFD] rounded-2xl border border-[#E9EEF6]">
            <p className="text-[#5F6368]">核心原因庫</p>
            <p className="text-lg font-bold text-[#7E22CE] mt-1">{reasons.length}</p>
          </div>
          <div className="p-3 bg-[#F8FAFD] rounded-2xl border border-[#E9EEF6]">
            <p className="text-[#5F6368]">已完成任務</p>
            <p className="text-lg font-bold text-emerald-600 mt-1">
              {notes.filter((n) => n.completed).length}
            </p>
          </div>
          <div className="p-3 bg-[#F8FAFD] rounded-2xl border border-[#E9EEF6]">
            <p className="text-[#5F6368]">星標收藏</p>
            <p className="text-lg font-bold text-amber-500 mt-1">
              {notes.filter((n) => n.starred).length}
            </p>
          </div>
        </div>
      </div>

      {/* Standalone Single File Exporter Card */}
      <div className="bg-gradient-to-br from-white to-[#F0F4F9] border border-[#BFDBFE] rounded-3xl p-6 shadow-xs space-y-3">
        <div className="flex items-center gap-2 text-sm font-bold text-[#0B57D0]">
          <FileCode2 className="w-5 h-5" />
          <span>導出單一獨立 HTML 檔案（Single-File Web App）</span>
        </div>
        <p className="text-xs text-[#5F6368] leading-relaxed">
          符合您的原生極簡技術需求：所有 HTML、CSS 樣式、JavaScript
          邏輯與目前所有的筆記資料將完全封裝在單一的 <code className="bg-blue-50 px-1.5 py-0.5 rounded text-blue-800">.html</code> 檔案中。不需要伺服器、Node.js 或網路，可隨身存放於隨身碟或任何電腦雙擊直接執行！
        </p>
        <button
          onClick={handleDownloadStandaloneHtml}
          className="pill-btn px-6 py-2.5 bg-[#0B57D0] hover:bg-[#0842A0] text-white text-xs font-semibold flex items-center gap-2 shadow-xs"
        >
          <Download className="w-4 h-4" />
          <span>一鍵導出單一獨立 HTML 檔案</span>
        </button>
      </div>

      {/* JSON Backup & Restore Card */}
      <div className="bg-white border border-[#E9EEF6] rounded-3xl p-6 shadow-[0_4px_20px_rgba(15,23,42,0.03)] space-y-4">
        <h2 className="text-sm font-bold text-[#1F1F1F]">JSON 資料備份與還原</h2>

        <div className="flex flex-wrap gap-3">
          <button
            onClick={handleExportJson}
            className="pill-btn px-4 py-2.5 bg-white border border-[#DCE3E9] hover:bg-[#F0F4F9] text-[#1F1F1F] text-xs font-medium flex items-center gap-2"
          >
            <Download className="w-4 h-4 text-gray-500" />
            <span>匯出 JSON 備份</span>
          </button>

          <label className="pill-btn px-4 py-2.5 bg-white border border-[#DCE3E9] hover:bg-[#F0F4F9] text-[#1F1F1F] text-xs font-medium flex items-center gap-2 cursor-pointer">
            <Upload className="w-4 h-4 text-gray-500" />
            <span>匯入 JSON 備份</span>
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleImportJson}
              accept=".json"
              className="hidden"
            />
          </label>
        </div>
      </div>

      {/* Reset Demo Data Card */}
      <div className="bg-white border border-red-100 rounded-3xl p-6 shadow-xs space-y-3">
        <h2 className="text-sm font-bold text-red-700">資料重設</h2>
        <p className="text-xs text-[#5F6368]">
          如果您想重新載入最初預設的示範資料（包含分子生物學作業、實驗室回信與減重羽球計劃），可隨時點擊重設。
        </p>
        <button
          onClick={() => {
            if (window.confirm('確定要將所有筆記還原為最初的預設示範資料嗎？')) {
              onResetDefault();
              showSuccess('已還原為初始示範資料！');
            }
          }}
          className="pill-btn px-4 py-2 bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 text-xs font-semibold flex items-center gap-1.5"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>重設為預設示範筆記</span>
        </button>
      </div>
    </div>
  );
};
