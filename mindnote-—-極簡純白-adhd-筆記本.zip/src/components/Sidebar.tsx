import React from 'react';
import {
  Home,
  GraduationCap,
  Pin,
  GitBranch,
  Lightbulb,
  Calendar,
  Search,
  Settings,
  Plus,
  PanelLeftClose,
  PanelLeftOpen,
  Sparkles,
} from 'lucide-react';
import { NavTab } from '../types';

interface SidebarProps {
  currentTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  onOpenQuickCapture: () => void;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
  totalNotesCount: number;
  academicCount: number;
  memoCount: number;
  flowCount: number;
  reasonCount: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onSelectTab,
  onOpenQuickCapture,
  isCollapsed,
  onToggleCollapse,
  academicCount,
  memoCount,
  flowCount,
  reasonCount,
}) => {
  const mainNavItems = [
    { id: 'home', label: '首頁總覽', icon: Home, count: null },
    { id: 'academic', label: '學術筆記', icon: GraduationCap, count: academicCount, badgeClass: 'bg-[#FEF2F2] text-[#B91C1C]' },
    { id: 'memo', label: '備忘錄', icon: Pin, count: memoCount, badgeClass: 'bg-[#EFF6FF] text-[#1D4ED8]' },
    { id: 'flow', label: '計劃流', icon: GitBranch, count: flowCount, badgeClass: 'bg-[#F0FDF4] text-[#15803D]' },
    { id: 'reason', label: '原因庫', icon: Lightbulb, count: reasonCount, badgeClass: 'bg-[#FAF5FF] text-[#7E22CE]' },
  ] as const;

  const toolNavItems = [
    { id: 'calendar', label: '日曆視圖', icon: Calendar },
    { id: 'search', label: '搜尋與標籤', icon: Search },
    { id: 'settings', label: '設定與備份', icon: Settings },
  ] as const;

  return (
    <aside
      className={`h-screen sticky top-0 bg-[#F0F4F9] flex flex-col justify-between p-4 transition-all duration-300 z-30 select-none ${
        isCollapsed ? 'w-20' : 'w-64'
      }`}
    >
      <div className="flex flex-col gap-6">
        {/* Brand Header */}
        <div className="flex items-center justify-between px-2 pt-2">
          {!isCollapsed && (
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-full bg-white flex items-center justify-center shadow-xs text-blue-600">
                <Sparkles className="w-5 h-5" />
              </div>
              <div className="overflow-hidden">
                <h1 className="font-bold text-base tracking-tight text-[#1F1F1F] leading-tight truncate">
                  MindNote
                </h1>
                <p className="text-[11px] text-[#5F6368] truncate">
                  快速記錄 · 有序規劃
                </p>
              </div>
            </div>
          )}

          {isCollapsed && (
            <div className="mx-auto w-9 h-9 rounded-full bg-white flex items-center justify-center shadow-xs text-blue-600">
              <Sparkles className="w-5 h-5" />
            </div>
          )}

          <button
            onClick={onToggleCollapse}
            aria-label={isCollapsed ? '展開側邊欄' : '收合側邊欄'}
            className="p-1.5 rounded-full hover:bg-[#E4EBF3] text-[#5F6368] transition-colors"
          >
            {isCollapsed ? <PanelLeftOpen className="w-4 h-4" /> : <PanelLeftClose className="w-4 h-4" />}
          </button>
        </div>

        {/* Primary Action Button */}
        <button
          onClick={onOpenQuickCapture}
          className={`pill-btn flex items-center justify-center gap-2 bg-[#0B57D0] hover:bg-[#0842A0] text-white font-medium shadow-xs ${
            isCollapsed ? 'w-12 h-12 p-0 mx-auto' : 'w-full py-3 px-5 text-sm'
          }`}
        >
          <Plus className="w-5 h-5" />
          {!isCollapsed && <span>快速寫入</span>}
        </button>

        {/* Main Navigation */}
        <div className="space-y-1">
          {!isCollapsed && (
            <p className="text-[11px] font-semibold text-[#5F6368] uppercase tracking-wider px-3 mb-2">
              分類空間
            </p>
          )}
          {mainNavItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onSelectTab(item.id as NavTab)}
                title={isCollapsed ? item.label : undefined}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-full text-sm font-medium transition-all ${
                  isActive
                    ? 'bg-white text-[#1F1F1F] shadow-xs font-semibold'
                    : 'text-[#5F6368] hover:bg-[#E4EBF3] hover:text-[#1F1F1F]'
                } ${isCollapsed ? 'justify-center px-0' : ''}`}
              >
                <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-[#0B57D0]' : 'text-[#5F6368]'}`} />
                {!isCollapsed && (
                  <span className="flex-1 text-left truncate">{item.label}</span>
                )}
                {!isCollapsed && item.count !== null && item.count > 0 && (
                  <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${item.badgeClass || 'bg-white/80 text-gray-700'}`}>
                    {item.count}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Tools Section */}
        <div className="space-y-1 pt-2">
          {!isCollapsed && (
            <p className="text-[11px] font-semibold text-[#5F6368] uppercase tracking-wider px-3 mb-2">
              視圖與工具
            </p>
          )}
          {toolNavItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onSelectTab(item.id as NavTab)}
                title={isCollapsed ? item.label : undefined}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-full text-sm font-medium transition-all ${
                  isActive
                    ? 'bg-white text-[#1F1F1F] shadow-xs font-semibold'
                    : 'text-[#5F6368] hover:bg-[#E4EBF3] hover:text-[#1F1F1F]'
                } ${isCollapsed ? 'justify-center px-0' : ''}`}
              >
                <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-[#0B57D0]' : 'text-[#5F6368]'}`} />
                {!isCollapsed && <span className="flex-1 text-left truncate">{item.label}</span>}
              </button>
            );
          })}
        </div>
      </div>

      {/* Motivation Footer (ADHD Support) */}
      {!isCollapsed && (
        <div className="bg-white/80 backdrop-blur-xs rounded-2xl p-3.5 border border-[#E9EEF6] text-xs text-[#5F6368] space-y-1.5 shadow-2xs">
          <div className="flex items-center gap-1.5 font-semibold text-[#1F1F1F]">
            <span className="text-amber-500">💡</span>
            <span>專注心法</span>
          </div>
          <p className="leading-relaxed text-[11px]">
            「不是只記下來，而是讓你願意做下去。」
          </p>
          <p className="text-[10px] text-gray-400 italic">
            小小的行動，會帶來巨大的改變。
          </p>
        </div>
      )}
    </aside>
  );
};
