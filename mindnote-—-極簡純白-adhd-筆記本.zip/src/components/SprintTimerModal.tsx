import React, { useState, useEffect } from 'react';
import { X, Play, Pause, RotateCcw, Plus, Sparkles, CheckCircle2 } from 'lucide-react';
import { playSuccessChime, playStartSprintChime } from '../utils/audio';

interface SprintTimerModalProps {
  isOpen: boolean;
  taskTitle: string;
  onClose: () => void;
  onComplete?: () => void;
}

const TOTAL_SECONDS = 15 * 60; // 15 minutes

export const SprintTimerModal: React.FC<SprintTimerModalProps> = ({
  isOpen,
  taskTitle,
  onClose,
  onComplete,
}) => {
  const [secondsLeft, setSecondsLeft] = useState(TOTAL_SECONDS);
  const [isActive, setIsActive] = useState(false);
  const [hasFinished, setHasFinished] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setSecondsLeft(TOTAL_SECONDS);
      setIsActive(true);
      setHasFinished(false);
      playStartSprintChime();
    }
  }, [isOpen]);

  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (isActive && secondsLeft > 0) {
      interval = setInterval(() => {
        setSecondsLeft((prev) => prev - 1);
      }, 1000);
    } else if (secondsLeft === 0 && isActive) {
      setIsActive(false);
      setHasFinished(true);
      playSuccessChime();
      if (onComplete) onComplete();
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isActive, secondsLeft, onComplete]);

  if (!isOpen) return null;

  const minutes = Math.floor(secondsLeft / 60);
  const seconds = secondsLeft % 60;
  const progressPercent = ((TOTAL_SECONDS - secondsLeft) / TOTAL_SECONDS) * 100;

  const handleTogglePlay = () => {
    if (!isActive) playStartSprintChime();
    setIsActive(!isActive);
  };

  const handleReset = () => {
    setIsActive(false);
    setSecondsLeft(TOTAL_SECONDS);
    setHasFinished(false);
  };

  const handleAdd5Minutes = () => {
    setSecondsLeft((prev) => prev + 5 * 60);
    setHasFinished(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs">
      <div className="bg-white rounded-3xl w-full max-w-md p-6 sm:p-8 shadow-[0_20px_50px_rgba(15,23,42,0.15)] border border-[#E9EEF6] text-center animate-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center gap-1.5 text-xs font-semibold px-3 py-1 rounded-full bg-blue-50 text-[#0B57D0]">
            <Sparkles className="w-3.5 h-3.5" />
            <span>ADHD 15 分鐘破冰微衝刺</span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-gray-100 text-[#5F6368] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Task Name */}
        <div className="mb-6">
          <p className="text-xs text-[#5F6368] mb-1">正在聚焦任務：</p>
          <h3 className="text-base sm:text-lg font-bold text-[#1F1F1F] line-clamp-2 px-4">
            {taskTitle || '專注微行動'}
          </h3>
        </div>

        {/* Circular Countdown Progress */}
        <div className="relative w-48 h-48 mx-auto mb-6 flex items-center justify-center">
          <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
            {/* Background circle */}
            <circle
              cx="50"
              cy="50"
              r="44"
              className="text-gray-100"
              strokeWidth="6"
              stroke="currentColor"
              fill="transparent"
            />
            {/* Progress circle */}
            <circle
              cx="50"
              cy="50"
              r="44"
              className="text-[#0B57D0] transition-all duration-1000 ease-linear"
              strokeWidth="6"
              strokeDasharray={276.46}
              strokeDashoffset={276.46 - (276.46 * progressPercent) / 100}
              strokeLinecap="round"
              stroke="currentColor"
              fill="transparent"
            />
          </svg>

          <div className="absolute inset-0 flex flex-col items-center justify-center">
            {hasFinished ? (
              <div className="flex flex-col items-center text-emerald-600 animate-bounce">
                <CheckCircle2 className="w-10 h-10 mb-1" />
                <span className="text-sm font-bold">衝刺完成！</span>
              </div>
            ) : (
              <>
                <span className="font-mono text-4xl font-extrabold tracking-tight text-[#1F1F1F]">
                  {String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
                </span>
                <span className="text-xs text-[#5F6368] mt-1">
                  {isActive ? '心流專注中' : '已暫停'}
                </span>
              </>
            )}
          </div>
        </div>

        {/* ADHD encouragement */}
        <p className="text-xs text-[#5F6368] italic mb-6">
          {hasFinished
            ? '太棒了！你跨越了最大的心理阻力，大腦多巴胺已經啟動。'
            : '只要撐過前幾分鐘，大腦就會進入心流。不追求完美，只求動起來！'}
        </p>

        {/* Controls */}
        <div className="flex items-center justify-center gap-3">
          <button
            onClick={handleReset}
            title="重新開始"
            className="p-3 rounded-full bg-[#F0F4F9] hover:bg-[#E4EBF3] text-[#5F6368] transition-colors"
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          <button
            onClick={handleTogglePlay}
            className={`pill-btn px-6 py-3 rounded-full flex items-center gap-2 font-semibold text-white shadow-md transition-transform ${
              isActive ? 'bg-amber-600 hover:bg-amber-700' : 'bg-[#0B57D0] hover:bg-[#0842A0]'
            }`}
          >
            {isActive ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-white" />}
            <span>{isActive ? '暫停' : '開始衝刺'}</span>
          </button>

          <button
            onClick={handleAdd5Minutes}
            title="加時 5 分鐘"
            className="p-3 rounded-full bg-[#F0F4F9] hover:bg-[#E4EBF3] text-[#5F6368] transition-colors flex items-center justify-center text-xs font-semibold"
          >
            <Plus className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
