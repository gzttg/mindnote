export type NoteType = 'academic' | 'memo' | 'flow' | 'reason';
export type EnergyLevel = 'high' | 'low';
export type BrainEnergyFilter = 'all' | 'high' | 'low';
export type NavTab = 'home' | 'academic' | 'memo' | 'flow' | 'reason' | 'calendar' | 'search' | 'settings';

export interface StepItem {
  id: string;
  text: string;
  completed: boolean;
}

export interface NoteItem {
  id: string;
  type: NoteType;
  title: string;
  content: string;
  createdAt: string; // ISO date
  dueDate?: string; // YYYY-MM-DD or YYYY-MM-DDTHH:mm
  energyLevel?: EnergyLevel;
  starred?: boolean;
  completed?: boolean;
  tags: string[];
  steps?: StepItem[];
  minimalFirstStep?: string;
  reason?: string;
  reasonId?: string;
}

export interface ReasonCard {
  id: string;
  title: string;
  benefit: string;
  consequence: string;
  tags: string[];
  timesUsed: number;
}
