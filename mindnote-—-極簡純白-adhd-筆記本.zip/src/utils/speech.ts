// Native Web Speech Recognition wrapper for voice quick input

export interface SpeechRecognitionHelper {
  isSupported: boolean;
  start: (onTranscript: (text: string) => void, onError: (err: string) => void) => void;
  stop: () => void;
}

// Browser API declarations
interface SpeechRecognitionErrorEvent extends Event {
  error: string;
}

interface SpeechRecognitionEvent extends Event {
  resultIndex: number;
  results: {
    [index: number]: {
      [index: number]: {
        transcript: string;
      };
      isFinal: boolean;
    };
    length: number;
  };
}

interface SpeechRecognitionInstance extends EventTarget {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  start: () => void;
  stop: () => void;
  abort: () => void;
  onresult: ((event: SpeechRecognitionEvent) => void) | null;
  onerror: ((event: SpeechRecognitionErrorEvent) => void) | null;
  onend: (() => void) | null;
}

type SpeechRecognitionConstructor = new () => SpeechRecognitionInstance;

export function createSpeechHelper(): {
  isSupported: boolean;
  start: (onText: (text: string) => void, onError: (msg: string) => void, onEnd: () => void) => () => void;
} {
  const isSupported = typeof window !== 'undefined' &&
    ('SpeechRecognition' in window || 'webkitSpeechRecognition' in window);

  let recognition: SpeechRecognitionInstance | null = null;

  const start = (
    onText: (text: string) => void,
    onError: (msg: string) => void,
    onEnd: () => void
  ) => {
    if (!isSupported) {
      onError('您的瀏覽器不支援語音辨識，請使用 Chrome / Edge 瀏覽器');
      return () => {};
    }

    try {
      const windowAny = window as unknown as {
        SpeechRecognition?: SpeechRecognitionConstructor;
        webkitSpeechRecognition?: SpeechRecognitionConstructor;
      };
      const RecognitionClass = windowAny.SpeechRecognition || windowAny.webkitSpeechRecognition;
      if (!RecognitionClass) return () => {};

      recognition = new RecognitionClass();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = 'zh-TW';

      recognition.onresult = (event: SpeechRecognitionEvent) => {
        let finalTranscript = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            finalTranscript += event.results[i][0].transcript;
          }
        }
        if (finalTranscript) {
          onText(finalTranscript);
        }
      };

      recognition.onerror = (event: SpeechRecognitionErrorEvent) => {
        if (event.error === 'no-speech') {
          // ignore silent pause
          return;
        }
        onError(`語音輸入提示: ${event.error}`);
      };

      recognition.onend = () => {
        onEnd();
      };

      recognition.start();

      return () => {
        if (recognition) {
          try {
            recognition.stop();
          } catch {
            // ignore
          }
        }
      };
    } catch (e) {
      onError('無法啟動麥克風，請檢查瀏覽器麥克風權限');
      return () => {};
    }
  };

  return {
    isSupported,
    start,
  };
}
