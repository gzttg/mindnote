import { NoteItem, ReasonCard } from '../types';

/**
 * 產生完全獨立、無外部依賴、純 HTML+CSS+JS 的單一檔案 Web App
 * 所有資料直接注入在腳本預設值中，任何瀏覽器直接點兩下即可離線運行。
 */
export function generateStandaloneHtml(notes: NoteItem[], reasons: ReasonCard[]): string {
  const notesJson = JSON.stringify(notes).replace(/</g, '\\u003c');
  const reasonsJson = JSON.stringify(reasons).replace(/</g, '\\u003c');

  return `<!DOCTYPE html>
<html lang="zh-TW">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>MindNote — 極簡純白 ADHD 筆記本</title>
  <style>
    :root {
      --bg-canvas: #F8FAFD;
      --bg-sidebar: #F0F4F9;
      --surface-card: #FFFFFF;
      --border-subtle: #E9EEF6;
      --border-hover: #DCE3E9;
      --text-primary: #1F1F1F;
      --text-secondary: #5F6368;
      --accent-blue: #0B57D0;
      --pastel-academic-bg: #FEF2F2;
      --pastel-academic-border: #FECACA;
      --pastel-academic-text: #B91C1C;
      --pastel-memo-bg: #EFF6FF;
      --pastel-memo-border: #BFDBFE;
      --pastel-memo-text: #1D4ED8;
      --pastel-flow-bg: #F0FDF4;
      --pastel-flow-border: #BBF7D0;
      --pastel-flow-text: #15803D;
      --pastel-reason-bg: #FAF5FF;
      --pastel-reason-border: #E9D5FF;
      --pastel-reason-text: #7E22CE;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      background-color: var(--bg-canvas);
      color: var(--text-primary);
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", "PingFang TC", "Noto Sans TC", sans-serif;
      display: flex;
      min-height: 100vh;
      overflow-x: hidden;
    }
    .pill {
      border-radius: 9999px;
      padding: 8px 18px;
      font-size: 14px;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 6px;
      border: 1px solid var(--border-hover);
      background: #FFFFFF;
      color: var(--text-primary);
      transition: all 0.2s cubic-bezier(0.2, 0, 0, 1);
      user-select: none;
    }
    .pill:hover {
      background: #F0F4F9;
      transform: translateY(-1px);
    }
    .pill.active {
      background: var(--text-primary);
      color: #FFFFFF;
      border-color: var(--text-primary);
    }
    .pill-primary {
      background: var(--accent-blue);
      color: #FFFFFF;
      border-color: var(--accent-blue);
    }
    .pill-primary:hover {
      background: #0842A0;
      color: #FFFFFF;
    }
    /* Pastel Pills */
    .badge-academic { background: var(--pastel-academic-bg); border: 1px solid var(--pastel-academic-border); color: var(--pastel-academic-text); border-radius: 9999px; padding: 4px 12px; font-size: 12px; font-weight: 600; display: inline-flex; align-items: center; gap: 4px; }
    .badge-memo { background: var(--pastel-memo-bg); border: 1px solid var(--pastel-memo-border); color: var(--pastel-memo-text); border-radius: 9999px; padding: 4px 12px; font-size: 12px; font-weight: 600; display: inline-flex; align-items: center; gap: 4px; }
    .badge-flow { background: var(--pastel-flow-bg); border: 1px solid var(--pastel-flow-border); color: var(--pastel-flow-text); border-radius: 9999px; padding: 4px 12px; font-size: 12px; font-weight: 600; display: inline-flex; align-items: center; gap: 4px; }
    .badge-reason { background: var(--pastel-reason-bg); border: 1px solid var(--pastel-reason-border); color: var(--pastel-reason-text); border-radius: 9999px; padding: 4px 12px; font-size: 12px; font-weight: 600; display: inline-flex; align-items: center; gap: 4px; }

    /* Layout */
    #sidebar {
      width: 260px;
      background: var(--bg-sidebar);
      padding: 24px 16px;
      display: flex;
      flex-direction: column;
      gap: 20px;
      flex-shrink: 0;
      transition: width 0.3s;
    }
    #main-content {
      flex: 1;
      padding: 32px 40px;
      max-width: 1200px;
      margin: 0 auto;
      width: 100%;
    }
    .logo {
      font-size: 18px;
      font-weight: 700;
      color: var(--text-primary);
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .nav-btn {
      width: 100%;
      text-align: left;
      padding: 12px 18px;
      border-radius: 9999px;
      background: transparent;
      border: none;
      font-size: 14px;
      font-weight: 500;
      color: var(--text-secondary);
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 10px;
      transition: all 0.2s cubic-bezier(0.2, 0, 0, 1);
    }
    .nav-btn:hover {
      background: #E4EBF3;
      color: var(--text-primary);
    }
    .nav-btn.active {
      background: #FFFFFF;
      color: var(--text-primary);
      box-shadow: 0 2px 8px rgba(15, 23, 42, 0.04);
      font-weight: 600;
    }
    /* Floating Bar */
    .floating-bar {
      background: #FFFFFF;
      border: 1px solid var(--border-subtle);
      border-radius: 28px;
      padding: 12px 20px;
      display: flex;
      align-items: center;
      gap: 12px;
      box-shadow: 0 4px 20px rgba(15, 23, 42, 0.03);
      transition: all 0.2s;
      margin-bottom: 32px;
    }
    .floating-bar:focus-within {
      box-shadow: 0 4px 20px rgba(66, 133, 244, 0.14), 0 0 0 1.5px #A8C7FA;
      border-color: #A8C7FA;
    }
    .floating-input {
      flex: 1;
      border: none;
      outline: none;
      font-size: 15px;
      background: transparent;
      color: var(--text-primary);
    }
    /* Card */
    .card {
      background: var(--surface-card);
      border: 1px solid var(--border-subtle);
      border-radius: 24px;
      padding: 24px;
      box-shadow: 0 4px 20px rgba(15, 23, 42, 0.03);
      transition: all 0.2s cubic-bezier(0.2, 0, 0, 1);
    }
    .card:hover {
      transform: translateY(-2px);
      box-shadow: 0 8px 24px rgba(15, 23, 42, 0.06);
    }
    .modal-overlay {
      position: fixed;
      top: 0; left: 0; right: 0; bottom: 0;
      background: rgba(15, 23, 42, 0.4);
      backdrop-filter: blur(4px);
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 1000;
      opacity: 0;
      pointer-events: none;
      transition: opacity 0.2s;
    }
    .modal-overlay.open {
      opacity: 1;
      pointer-events: auto;
    }
    .modal-box {
      background: #FFFFFF;
      border-radius: 24px;
      padding: 28px;
      max-width: 600px;
      width: 92%;
      max-height: 90vh;
      overflow-y: auto;
      box-shadow: 0 20px 40px rgba(15, 23, 42, 0.12);
    }
  </style>
</head>
<body>
  <aside id="sidebar">
    <div class="logo">
      <span>✨</span>
      <span>MindNote</span>
    </div>
    <p style="font-size: 11px; color: var(--text-secondary); line-height: 1.4;">快速記錄 · 有序規劃 · 為了更好的你</p>
    <button class="pill pill-primary" onclick="openNewModal()" style="width: 100%; justify-content: center; padding: 12px 20px;">
      ＋ 快速新增筆記
    </button>
    <nav style="display: flex; flex-direction: column; gap: 6px; margin-top: 10px;">
      <button class="nav-btn active" onclick="switchTab('home', this)">🏠 首頁待辦</button>
      <button class="nav-btn" onclick="switchTab('academic', this)">🎓 學術筆記</button>
      <button class="nav-btn" onclick="switchTab('memo', this)">📌 備忘錄</button>
      <button class="nav-btn" onclick="switchTab('flow', this)">🟢 計劃流</button>
      <button class="nav-btn" onclick="switchTab('reason', this)">💡 原因庫</button>
    </nav>
    <div style="margin-top: auto; padding: 16px; background: #FFFFFF; border-radius: 16px; font-size: 12px; color: var(--text-secondary); line-height: 1.6;">
      <div style="font-weight: 600; color: var(--text-primary); margin-bottom: 4px;">🌱 每日專注</div>
      「不是只記下來，而是讓你願意做下去。」
    </div>
  </aside>

  <main id="main-content">
    <!-- Gemini Floating Prompt Bar -->
    <div class="floating-bar">
      <span>✨</span>
      <input id="quickInput" class="floating-input" placeholder="有什麼想記下的？輸入後按 Enter 立即捕捉..." onkeydown="if(event.key==='Enter') quickAddNote()">
      <button class="pill pill-primary" onclick="quickAddNote()" style="padding: 6px 16px; font-size: 13px;">新增</button>
      <button class="pill" onclick="openNewModal()" style="padding: 6px 14px; font-size: 13px;">完整表單</button>
    </div>

    <!-- Energy Filter Bar -->
    <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 24px; flex-wrap: wrap; gap: 12px;">
      <div>
        <h1 style="font-size: 24px; font-weight: 700; color: var(--text-primary); margin-bottom: 4px;">今日行動中心</h1>
        <p style="font-size: 13px; color: var(--text-secondary);">小小的行動，會帶來巨大的改變。</p>
      </div>
      <div style="display: flex; gap: 8px;">
        <button class="pill active" id="filter-all" onclick="setEnergyFilter('all', this)">全部</button>
        <button class="pill" id="filter-high" onclick="setEnergyFilter('high', this)">🔋 高能量燒腦</button>
        <button class="pill" id="filter-low" onclick="setEnergyFilter('low', this)">🪫 低能量無腦</button>
      </div>
    </div>

    <!-- Today Action List -->
    <div class="card" style="margin-bottom: 32px;">
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
        <h2 style="font-size: 16px; font-weight: 600;">⚡ 今日待辦與微行動</h2>
        <span id="todoCount" style="font-size: 12px; color: var(--text-secondary);"></span>
      </div>
      <div id="todoList" style="display: flex; flex-direction: column; gap: 10px;"></div>
    </div>

    <!-- Notes Stream -->
    <h2 style="font-size: 18px; font-weight: 600; margin-bottom: 16px;">📚 筆記與任務列表</h2>
    <div id="notesGrid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap: 16px;"></div>
  </main>

  <!-- Modal for Creating Note -->
  <div id="createModal" class="modal-overlay">
    <div class="modal-box">
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <h3 style="font-size: 18px; font-weight: 700;">快速寫入筆記</h3>
        <button onclick="closeNewModal()" style="border: none; background: none; font-size: 20px; cursor: pointer; color: var(--text-secondary);">✕</button>
      </div>
      <div style="display: flex; gap: 8px; margin-bottom: 16px;">
        <button type="button" class="badge-academic pill" onclick="setModalType('academic')">🔴 學術</button>
        <button type="button" class="badge-memo pill" onclick="setModalType('memo')">🔵 備忘錄</button>
        <button type="button" class="badge-flow pill" onclick="setModalType('flow')">🟢 計劃流</button>
        <button type="button" class="badge-reason pill" onclick="setModalType('reason')">🟣 原因</button>
      </div>
      <input id="noteTitle" placeholder="標題（可留空，自動擷取前15字）" style="width: 100%; padding: 12px 16px; border-radius: 12px; border: 1px solid var(--border-subtle); margin-bottom: 12px; font-size: 15px;">
      <textarea id="noteContent" rows="4" placeholder="詳細內容..." style="width: 100%; padding: 12px 16px; border-radius: 12px; border: 1px solid var(--border-subtle); margin-bottom: 12px; font-size: 14px; font-family: inherit;"></textarea>
      <input id="noteMinimalStep" placeholder="⚡ 最小第一步 (例如: 打開講義翻到第1頁)" style="width: 100%; padding: 12px 16px; border-radius: 12px; border: 1px solid var(--border-subtle); margin-bottom: 12px; font-size: 14px;">
      <input id="noteReason" placeholder="🟣 為什麼現在要做？(好處或拖延嚴重性)" style="width: 100%; padding: 12px 16px; border-radius: 12px; border: 1px solid var(--border-subtle); margin-bottom: 16px; font-size: 14px;">
      <div style="display: flex; justify-content: flex-end; gap: 10px;">
        <button class="pill" onclick="closeNewModal()">取消</button>
        <button class="pill pill-primary" onclick="saveNewNote()">儲存筆記</button>
      </div>
    </div>
  </div>

  <script>
    // Embedded Data & State
    let currentTab = 'home';
    let energyFilter = 'all';
    let modalSelectedType = 'academic';

    const defaultNotes = ${notesJson};
    const defaultReasons = ${reasonsJson};

    let notes = JSON.parse(localStorage.getItem('mindnote_notes')) || defaultNotes;
    let reasons = JSON.parse(localStorage.getItem('mindnote_reasons')) || defaultReasons;

    function saveState() {
      localStorage.setItem('mindnote_notes', JSON.stringify(notes));
      localStorage.setItem('mindnote_reasons', JSON.stringify(reasons));
      render();
    }

    // Audio Chime (Web Audio API)
    function playChime() {
      try {
        const AudioCtx = window.AudioContext || window.webkitAudioContext;
        if (!AudioCtx) return;
        const ctx = new AudioCtx();
        const now = ctx.currentTime;
        const osc1 = ctx.createOscillator();
        const gain1 = ctx.createGain();
        osc1.frequency.setValueAtTime(587.33, now);
        gain1.gain.setValueAtTime(0, now);
        gain1.gain.linearRampToValueAtTime(0.2, now + 0.05);
        gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.8);
        osc1.connect(gain1); gain1.connect(ctx.destination);
        osc1.start(now); osc1.stop(now + 0.8);

        const osc2 = ctx.createOscillator();
        const gain2 = ctx.createGain();
        osc2.frequency.setValueAtTime(880, now + 0.1);
        gain2.gain.setValueAtTime(0, now + 0.1);
        gain2.gain.linearRampToValueAtTime(0.25, now + 0.15);
        gain2.gain.exponentialRampToValueAtTime(0.001, now + 1.0);
        osc2.connect(gain2); gain2.connect(ctx.destination);
        osc2.start(now + 0.1); osc2.stop(now + 1.0);
      } catch (e) {}
    }

    function quickAddNote() {
      const input = document.getElementById('quickInput');
      const val = input.value.trim();
      if (!val) return;
      const newNote = {
        id: 'note-' + Date.now(),
        type: 'memo',
        title: val.slice(0, 20),
        content: val,
        createdAt: new Date().toISOString(),
        dueDate: new Date().toISOString().split('T')[0],
        energyLevel: 'low',
        completed: false,
        tags: ['#快速記錄'],
        minimalFirstStep: '先做2分鐘'
      };
      notes.unshift(newNote);
      input.value = '';
      saveState();
      playChime();
    }

    function toggleNote(id) {
      notes = notes.map(n => n.id === id ? { ...n, completed: !n.completed } : n);
      saveState();
      playChime();
    }

    function render() {
      const todoList = document.getElementById('todoList');
      const notesGrid = document.getElementById('notesGrid');
      
      let filtered = notes;
      if (currentTab !== 'home') {
        filtered = filtered.filter(n => n.type === currentTab);
      }
      if (energyFilter !== 'all') {
        filtered = filtered.filter(n => n.energyLevel === energyFilter);
      }

      // Render Todos
      const pending = filtered.filter(n => !n.completed);
      document.getElementById('todoCount').textContent = \`尚有 \${pending.length} 項待辦\`;
      
      todoList.innerHTML = filtered.map(n => \`
        <div style="display:flex;align-items:center;justify-content:space-between;padding:12px 16px;background:#F8FAFD;border-radius:16px;">
          <div style="display:flex;align-items:center;gap:12px;">
            <input type="checkbox" \${n.completed ? 'checked' : ''} onchange="toggleNote('\${n.id}')" style="width:18px;height:18px;cursor:pointer;">
            <div style="\${n.completed ? 'text-decoration:line-through;color:#9CA3AF;' : ''}">
              <div style="font-weight:600;font-size:14px;">\${n.title}</div>
              <div style="font-size:12px;color:var(--text-secondary);">⚡ \${n.minimalFirstStep || '先做2分鐘'}</div>
            </div>
          </div>
          <div style="display:flex;align-items:center;gap:8px;">
            <span class="badge-\${n.type}">\${n.type === 'academic' ? '學術' : n.type === 'memo' ? '備忘' : n.type === 'flow' ? '計劃' : '原因'}</span>
            <button class="pill" onclick="alert('⚡ 最小第一步專注：' + '\${n.minimalFirstStep || n.title}')" style="padding:4px 10px;font-size:11px;">⚡ 先做2分鐘</button>
          </div>
        </div>
      \`).join('');

      // Render Grid
      notesGrid.innerHTML = filtered.map(n => \`
        <div class="card">
          <div style="display:flex;justify-content:space-between;margin-bottom:12px;">
            <span class="badge-\${n.type}">\${n.type}</span>
            <span style="font-size:12px;color:var(--text-secondary);">\${n.energyLevel === 'high' ? '🔋 高能' : '🪫 低能'}</span>
          </div>
          <h3 style="font-size:16px;font-weight:700;margin-bottom:8px;">\${n.title}</h3>
          <p style="font-size:13px;color:var(--text-secondary);line-height:1.5;margin-bottom:16px;">\${n.content}</p>
          \${n.reason ? \`<div style="background:var(--pastel-reason-bg);border:1px solid var(--pastel-reason-border);padding:10px 14px;border-radius:12px;font-size:12px;color:var(--pastel-reason-text);margin-bottom:12px;">💡 \${n.reason}</div>\` : ''}
          <div style="display:flex;justify-content:space-between;align-items:center;font-size:12px;color:var(--text-secondary);">
            <span>\${n.tags ? n.tags.join(' ') : ''}</span>
            <button class="pill" onclick="toggleNote('\${n.id}')" style="padding:4px 12px;font-size:12px;">\${n.completed ? '已完成' : '標記完成'}</button>
          </div>
        </div>
      \`).join('');
    }

    function switchTab(tab, btn) {
      currentTab = tab;
      document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
      if (btn) btn.classList.add('active');
      render();
    }

    function setEnergyFilter(type, btn) {
      energyFilter = type;
      document.querySelectorAll('#filter-all, #filter-high, #filter-low').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      render();
    }

    function openNewModal() { document.getElementById('createModal').classList.add('open'); }
    function closeNewModal() { document.getElementById('createModal').classList.remove('open'); }
    function setModalType(type) { modalSelectedType = type; }
    function saveNewNote() {
      const titleInput = document.getElementById('noteTitle').value.trim();
      const content = document.getElementById('noteContent').value.trim();
      const minimalStep = document.getElementById('noteMinimalStep').value.trim();
      const reason = document.getElementById('noteReason').value.trim();
      const title = titleInput || (content ? content.slice(0, 15) : '無標題筆記');

      const newNote = {
        id: 'note-' + Date.now(),
        type: modalSelectedType,
        title,
        content,
        createdAt: new Date().toISOString(),
        dueDate: new Date().toISOString().split('T')[0],
        energyLevel: 'high',
        completed: false,
        tags: ['#筆記'],
        minimalFirstStep: minimalStep || '開始第1分鐘',
        reason
      };
      notes.unshift(newNote);
      saveState();
      closeNewModal();
      playChime();
    }

    render();
  </script>
</body>
</html>`;
}

/**
 * 觸發瀏覽器下載單一 HTML 檔案
 */
export function downloadStandaloneHtmlFile(notes: NoteItem[], reasons: ReasonCard[]) {
  const htmlContent = generateStandaloneHtml(notes, reasons);
  const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `MindNote_Standalone_${new Date().toISOString().slice(0, 10)}.html`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
